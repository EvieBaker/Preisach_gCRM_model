import angles as an
import general as ge
import plots as pl
import copy 
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
import os as os
from math import pi, log, log10, ceil, cos, sin, sqrt, acos
import time
import random


start_time = time.time()

#constant variables 
tempt=300.
ms0 = 491880.5
mu0 = 4.*pi*1e-7
kb = 1.3806503e-23
tau = 1e-9
roottwohffield = 2.**(0.5)  
sumegli = 0.0
eglip=0.54
hf=(10000.**(0.54))*(10.**(-0.52)) 
eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)

eul = 1.78107 #exp(eulers const)

fieldzero = 0

#declare dictionaries 
V = {}
ST = {}
SC = {}
I = {}
TT = {}
CT = {} 

V['name'] = 'PN2_angle' # input name of sample
V['variable_c'] = 'PN2_angle' # variable changing


V['variable_change'] = np.array((0., 90., 180.))



len_var = len(V['variable_change'])
V['len_var'] = len_var
var_c =0 

#variables for preisach distribution
mu_y = 0.00
mu_x = 0.015 
variance_x = 0.00007 
xmax = 0.03

#field parameters
minf = 50E-6
maxf = 150E-6
num_fields = 3.
fieldmax=maxf/mu0
fieldmin= minf/mu0 
fieldstep=(fieldmax-fieldmin)/num_fields 
field = 50.0E-6/mu0 #overwrite just 1 field
V['field'] = field


num_hyss_pre = 1000000 
V['num_hyss'] = num_hyss_pre

#temp parameters
tempmax=577.+273. # one degree less than Tc
tempmin=300. 
V['tempmin'] = tempmin
V['tempmax'] = tempmax
tempstep=1.
V['tempstep'] = tempstep

#time constant in hours
ac = 1. 

#CRM growth rate
g = 1E-13


ST['err_t'] = 0.0 
ST['err_s'] = 0.0 
SC['err_c'] = 0.0 
SC['err_s'] = 0.0 

TT['err_t'] = 0.0 
CT['err_c'] = 0.0 
TT['err_s'] = 0.0 
CT['err_s'] = 0.0 
CT['err_t'] = 0.0

variable_change = V['variable_change']


current_directory = os.getcwd()
final_directory = os.path.join(current_directory, V['variable_c'])
if not os.path.exists(final_directory):
    os.makedirs(final_directory)
    
V['dir'] = final_directory

#arrays for tracking and plotting 
ge.make_arrays_a(ST, SC, TT, CT, V)

var_c = 0

for var_c in range(len(V['variable_change'])):
    

    V['end_mag'] = 0.0


    cntfield = ST['cntfield']
    demag_f = 50E-6 
    demag_field = demag_f/mu0
    TT['demag_field'] = demag_field
    CT['demag_field'] = demag_field

    field = (50E-6)/mu0
    V['field'] = (50E-6)/mu0    
    
    V['num_hyss'] = num_hyss_pre

    #FILL PREISACH DISTRIBUTION 
    ymax = 0.007
    stdev_y = 0.001
    variance_y = ((stdev_y)**2)
    mu_x = 0.02
    stdev_x = 7E-3
    variance_x = (stdev_x)**2
    xmax = 0.04
    cntfield = ST['cntfield']


    x = np.linspace(0,xmax,250)
    y = np.linspace(-ymax,ymax,250)
    X, Y = np.meshgrid(x,y)
    
    pos = np.empty(X.shape + (2,))
    pos[:, :, 0] = X; pos[:, :, 1] = Y
    rv = multivariate_normal([mu_x, mu_y], [[variance_x, 0], [0, variance_y]])
    z = rv.pdf(pos)
    

    ST['x'] = X
    ST['y'] = Y
    ST['z'] = z
    SC['x'] = X
    SC['y'] = Y
    SC['z'] = z
    I['x'] = X
    I['y'] = Y
    I['z'] = z
    ge.norm_z(ST, SC, I, var_c)
    pl.plot_z(V, ST, SC, I, var_c)
    ms=ms0*(1-(tempt-273)/578.0)**0.43 
    tm = 0.2
    I['ms'] = ms
    I['tm'] = tm
    
    #populate angles
    afone = 1
    afzero = 0
    
    
    hys, num_pop, angles = ge.pop_hys_a(num_hyss_pre, V, I) #populate hysterons with angles
    I['hys'] = hys

    I['angles'] = angles 
    I,V = ge.blocked_hys(I,V)    
    mean_int = np.sum((abs(hys[:,1]))*hys[:,3])
    mean_int_1 = mean_int/np.sum(hys[:,3])
    mean_int_2 = mean_int_1*mu0
    V['mean_int_field'][var_c] = mean_int_2
    num_hyss = V['num_hyss'] 


    phi_field = 0.0
    theta_field = 0.0
    #dot product for smallest angle between first applied field and easy axis 
    x_f1 = sin(phi_field)*cos(theta_field)
    y_f1 = sin(phi_field)*sin(theta_field)
    z_f1 = cos(phi_field)  
    x_f = x_f1/sqrt(x_f1**2+y_f1**2 + z_f1**2)
    y_f = y_f1/sqrt(x_f1**2+y_f1**2 + z_f1**2)      
    z_f = z_f1/sqrt(x_f1**2+y_f1**2 + z_f1**2)


    a_t = 0
    for a_t in range(len(I['angles'])): 
        x_coeff_e = I['angles'][a_t,5]
        y_coeff_e = I['angles'][a_t,6]
        z_coeff_e = I['angles'][a_t,7]
        
        top = (x_f*x_coeff_e) + (y_f*y_coeff_e) + (z_f*z_coeff_e)
        bottom = (sqrt((x_f**2) + (y_f**2) + (z_f**2))*sqrt((x_coeff_e**2) + (y_coeff_e**2) + (z_coeff_e**2)))
        
        new_phi = acos(top/bottom)
        
        if (new_phi > pi/2):
            I['hys'][a_t,5] = pi - new_phi
            I['angles'][a_t,4] = -1.
            print('not expected')
        else:
            I['hys'][a_t, 5] = new_phi
            I['angles'][a_t, 4] = 1.   
          
    #determine smallest angle between new field direction and each particles easy axis
    phi_field_2 = (V['variable_change'][var_c])*(pi/180.)
   

    theta_field_2 = 0.0
    x_nf1 = sin(phi_field_2)*cos(theta_field_2)
    y_nf1 = sin(phi_field_2)*sin(theta_field_2)
    z_nf1 = cos(phi_field_2)
    x_nf = x_nf1/sqrt(x_nf1**2+y_nf1**2 + z_nf1**2)
    y_nf = y_nf1/sqrt(x_nf1**2+y_nf1**2 + z_nf1**2)      
    z_nf = z_nf1/sqrt(x_nf1**2+y_nf1**2 + z_nf1**2)    
    
    
    
    a_t = 0
    for a_t in range(len(I['angles'])): 
        x_coeff_e = I['angles'][a_t,5]
        y_coeff_e = I['angles'][a_t,6]
        z_coeff_e = I['angles'][a_t,7]
        
        top = (x_nf*x_coeff_e) + (y_nf*y_coeff_e) + (z_nf*z_coeff_e)
        bottom = (sqrt((x_nf**2) + (y_nf**2) + (z_nf**2))*sqrt((x_coeff_e**2) + (y_coeff_e**2) + (z_coeff_e**2)))
        
        new_phi = acos(top/bottom)
        
        if (new_phi > pi/2):
            I['angles'][a_t,8] = pi - new_phi
            I['angles'][a_t,4] = -1.
        else:
            I['angles'][a_t, 8] = new_phi
            I['angles'][a_t, 4] = 1.   
        
    print(I['angles'][:10, 8])
    print(I['hys'][:10,5])         
    print(np.sum(I['angles'][:,8]))
    print(np.sum(I['hys'][:,5]))

   
    V['totalvol'] = np.sum(I['hys'][:,10])
    V['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
    #CRM model
    eglip=0.0
    hf=(10000**(0.54))*(10**(-0.52))
    eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)

    SC['blockper'] = 0.0

    SC['hcstore'] = np.zeros(num_hyss)
    SC['histore'] = np.zeros(num_hyss)    
    SC['count_b'] =0

    SC['warm'] = 0.0
    SC['heating'] = 0.0

    #main CRM model
    final_R = np.zeros(num_hyss) 

    SC['tm'] = 0.2

    SC['countiold'] = num_hyss 

    af_step = SC['AF_steps']
    SC['blocktemp'] = np.zeros(num_hyss)
    SC['boltz'] = np.zeros(num_hyss)
    SC['blockg'] = np.zeros(num_hyss)
    SC['totalm'] = 0
    SC['sir'] = 0
    SC['aftotalm'] = 0

    temp= tempmin + 0.1

    SC['tm'] = 0.2
    SC['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
    SC['beta'] = (1-((temp-273)/578.0))**0.43
    SC['ms'] = ms0*SC['beta']
    SC['temp'] = temp

    SC['sense'] = np.ones(num_hyss)

    rate = 1 
    t =0 
    V['end_mag'] = 0.0
    SC['rate'] = rate

    afswitch = afzero

    SC['hys'] = copy.deepcopy(I['hys'])
    SC['angles'] = copy.deepcopy(I['angles'])    
    hys = np.copy(SC['hys'])

    Ro = 1E-09#nucleation radius 
    prop = np.zeros((num_hyss,12))
    prop[:,9] = ms*mu0*hys[:,9] #eo for constant de/dv 
    prop[:,0] = hys[:,10] #Vf
    prop[:,1] = (3*prop[:,0]/(4*pi))**(1./3.) #Rf 
    final_R = prop[:,1]
    prop[:,2] = (prop[:,1] - Ro)/g #growth time in seconds
    maxt = np.max(prop[:,2]) #max growth time 
    prop[:,3] = (maxt- prop[:,2])#nucleation time for each 

    SC['prop'] = np.copy(prop)
    SC['totalvol'] = sum(prop[:,0])

    #CRM acquisition

    t = 0
    tstep = maxt/3000. 
    SC['tstep'] = tstep

    tot_time_steps = (np.max(prop[:,2])+0.5*tstep)/tstep
    tot_time_steps = ceil(tot_time_steps)

    tm = 0

    SC['aftotalm'] = 0
    SC['tm'] = tm 
    x=0 #loop over time steps
    field = V['field']
   
    V['end_mag'] = 1.0

    SC['afstore'] = 0
    
   

    #calc SIRM 

    prop = SC['prop']

    tm = 60.0
    prop[:,10] = 60.0
    prop[:,5] = np.copy(hys[:,10])
    SC['prop'] = prop
    t = np.max(prop[:,2]) 
    SC['blocktemp'] = np.ones(num_hyss)
    SC['boltz'] = np.ones(num_hyss)
    SC['blockg'] = np.ones(num_hyss)
    SC['blockper'] = 1.

    SC['sir'] = 0
    SC['afstore'] = 0.0

    an.blockfind_SC(t, fieldzero, afone, V, SC)

    cntfields = cntfield 
   
    SC['sirm'][var_c,0] = SC['sir']
    #SIRM and demag SIRM 
    SC['sirm_phi'][var_c, 0] = SC['phi_totalm']
    SC['sirm_theta'][var_c, 0] = SC['theta_totalm'] 
    for i in range(cntfield): 
        for kk in range(1):
            afstore_C = af_step[i]
            SC['afstore'] = afstore_C
            an.blockfind_SC(t, fieldzero, afone, V, SC)
            SC['sirm'][var_c,i] = SC['sir']
            SC['sirm_phi'][var_c, i] = SC['phi_totalm']
            SC['sirm_theta'][var_c, i] = SC['theta_totalm'] 




    ST['sirm'] = np.copy(SC['sirm'])

    pl.plot_sirm(SC, SC, V, var_c) 


    eglip=0.54
    hf=(10000.**(0.54))*(10.**(-0.52)) 
    eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)

    blockper = 0.0
    TT['blockper'] = blockper
    TT['hcstore'] = np.zeros(num_hyss)
    TT['histore'] = np.zeros(num_hyss)
    TT['countiold'] = num_hyss 

    TT['oldblockg'] = np.zeros(num_hyss)
    TT['blocktemp'] = np.zeros(num_hyss)
    TT['boltz'] = np.zeros(num_hyss)
    TT['blockg'] = np.zeros(num_hyss)
    TT['unblocked'] = np.zeros(num_hyss)
    TT['totalm'] = 0.
    TT['sir'] = 0.
    TT['aftotalm'] = 0.
    TT['afstore'] = 0.0
    TT['sirm'] = np.copy(ST['sirm'])
    
    temp=300.

    ms=ms0*(1.-(tempt-273.)/578.0)**0.43 
    TT['ms'] = ms
    tm = 0.2 
    TT['tm'] = tm
    TT['sense'] = np.ones(num_hyss)
    temp = tempmax
    rate = 1
    TT['rate'] = rate

    afswitch = afzero

    TT['hys'] = copy.deepcopy(I['hys']) 
    TT['angles'] = copy.deepcopy(I['angles'])    

    tm = 0.

    TT['aftotalm'] = 0
    TT['tm'] = tm 
    track = 0

    ac = 1.
    field = V['field']
    TT['reheat'] = 'trm'
    variable_change = V['variable_change']
    dire = V['dir']
    V['end_mag'] = 0.0
    

    TT['heating'] = 0.0
    TT['warm'] = 0.0
    #TRM acquistion 
    while (temp > tempmin):


        TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
        TT['beta'] = (1.-(temp-273.)/578.0)**0.43

        an.blockfind_TT(temp, field, afzero, V, TT)
        TT['trm_a'][var_c][track] = TT['totalm'] 
        TT['temp_a'][var_c][track] = temp
        TT['trm_phi_a'][var_c, track] = TT['phi_totalm']
        TT['trm_theta_a'][var_c, track] = TT['theta_totalm']      
       
        
        if (temp <= 750.):
            tempstep1 = tempstep*10.
        elif (temp <= 840.) and (temp > 800.):
            tempstep1 = tempstep/4.
        else:
            tempstep1 = tempstep
        temp = temp - tempstep1
        track += 1


    TT['len_a_trm'][var_c] = track 

    temp = temp + 0.1
    TT['beta'] = (1.-(temp-273.)/578.0)**0.43	
    an.blockfind_TT(temp, field, afzero, V, TT)
	
    field = 0.0

    V['end_mag'] = 1.0

    an.blockfind_TT(temp, field, afzero, V, TT) 

    V['end_mag'] = 0.0
    

    td = 0


    #max TRM
    TT['max_trm'][var_c] = TT['totalm']
 

    TT['hys'][:,5] = copy.deepcopy(TT['angles'][:,8])

    
	
	#temp steps for Thellier protocol
    Ttest_arr = np.array([320., 400., 500., 600., 700., 750., 775., 780., 785., 790., 795., 800.,805., 807., 810., 812., 815., 818., 820., 821., 823., 824., 825., 826., 827., 828., 830., 831., 833., 835., 837., 840., 849., 860.])

    ptrm_t = np.array([0., 0., 0., 0., 1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 0., 1., 0., 1., 0., 0., 0.])
    tail_t = np.array([0., 0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 1., 0., 1., 0., 0., 0.])

    Ttest = Ttest_arr[td]

    temp = tempmin + tempstep*10.
    p = 0 # track ptrm temps
    t = 0
    k = 1

    TT['temp_PI'][var_c, 0] = tempmin
    TT['mag_PI'][var_c, 0] = TT['totalm']
    TT['phi_PI'][var_c, 0] = TT['phi_totalm']       
    TT['theta_PI'][var_c, 0] = TT['theta_totalm']      
    

    ac = 1. 
    print('before thellier')
    
    TT['heating'] = 1.
    #thellier method  - more detail on which are zero field and field heating steps in non-angle code version
    while (Ttest < tempmax):
        
        while (temp <= Ttest): #heat up to Ttest in zero field for TRM_lost step
                        
            TT['warm'] = 1.0
            field = 0.0
            TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TT['beta'] = (1-(temp-273)/578.0)**0.43

            an.blockfind_TT(temp, field, afzero, V, TT) #mag remain at temp step 



            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/4.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1

        while (temp > tempmin): #cool down in zero field from temerature step and measure magnetisation
            TT['warm'] = 0.0
            TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TT['beta'] = (1-(temp-273)/578.0)**0.43
            an.blockfind_TT(temp, field, afzero, V, TT) #mag remain at temp step 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/4.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1       
        
        temp = temp + tempstep1 

        
        temp_r = 300.1
        TT['beta'] = (1-(temp_r-273)/578.0)**0.43
        an.blockfind_TT(temp_r, field, afzero, V, TT)
        V['end_mag'] = 1.0
        field = 0.0

        an.blockfind_TT(temp_r, field, afzero, V, TT) 
      
        TT['NRM_r'][var_c, td] = TT['totalm'] #NRM remaining magnetisation after heating in zero field to test field step      
        TT['temp_PI'][var_c, k] = Ttest 
        TT['mag_PI'][var_c, k] = TT['totalm']
        TT['phi_PI'][var_c, k] = TT['phi_totalm']       
        TT['theta_PI'][var_c, k] = TT['theta_totalm'] 
        k+=1

        V['end_mag'] = 0.0
        TT['Ttest_list'][var_c, td] = Ttest
        
        if (ptrm_t[td] == 1.): #pTRM check is valid for this step
            TT['temp_heat'][var_c, td] = Ttest 
            TT['temp_check'][var_c, td] = Ttest_arr[td-2]
            while (temp <= Ttest_arr[td-2]): 
                TT['reheat'] = 'yes'
                TT['warm'] = 1.0

                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                TT['beta'] = beta
                field = TT['demag_field']
                an.blockfind_TT(temp, field, afzero, V, TT)  

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/4.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            TT['warm'] = 0.0
            while (temp > tempmin): 

                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                TT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                TT['beta'] = beta
                field = TT['demag_field']
                an.blockfind_TT(temp, field, afzero, V, TT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/4.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1 
                
            temp = temp + tempstep1    

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TT['aconst'] = aconst
            beta= (1.-(temp_r-273.)/578.0)**0.43
            TT['beta'] = beta
			
            an.blockfind_TT(temp_r, field, afzero, V, TT)
			
            V['end_mag'] = 1.0

            field = 0.0
            an.blockfind_TT(temp_r, field, afzero, V, TT) 
 
            V['end_mag'] = 0.0
            ptrm = TT['totalm']
			
            TT['NRM_check'][var_c,td] = TT['NRM_r'][var_c, td]

            TT['pTRM_M3'][var_c, td] = ptrm

            TT['pTRM_check'][var_c, td] = ptrm - TT['NRM_r'][var_c, td] 
			
            TT['temp_PI'][var_c, k] = Ttest_arr[td-2] + 0.2
            TT['mag_PI'][var_c, k] = TT['totalm']
            TT['phi_PI'][var_c, k] = TT['phi_totalm']       
            TT['theta_PI'][var_c, k] = TT['theta_totalm']             
            
            k+=1
			
			
            p +=1
			
        while (temp <= Ttest): 
            TT['reheat'] = 'yes'
            TT['warm'] = 1.0

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            TT['beta'] = beta
            field = TT['demag_field']
            an.blockfind_TT(temp, field, afzero, V, TT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/4.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1

        
        while (temp > tempmin): 

            TT['warm'] = 0.0
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            TT['beta'] = beta
            field = TT['demag_field']
            an.blockfind_TT(temp, field, afzero, V, TT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/4.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1   

        temp = temp + tempstep1

        aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
        TT['aconst'] = aconst
        beta= (1.-(temp_r-273.)/578.0)**0.43
        TT['beta'] = beta

        an.blockfind_TT(temp_r, field, afzero, V, TT)
		
        TT['Ttest_list'][var_c, td] = Ttest
        V['end_mag'] = 1.0

        field = 0.0
        an.blockfind_TT(temp_r, field, afzero, V, TT) 

        V['end_mag'] = 0.0
        TT['M_2'][var_c, td] = TT['totalm']

        TT['pTRM'][var_c, td] = TT['M_2'][var_c, td] - TT['NRM_r'][var_c, td] 

        TT['temp_PI'][var_c, k] = Ttest + 0.1
        TT['mag_PI'][var_c, k] = TT['totalm']
        TT['phi_PI'][var_c, k] = TT['phi_totalm']       
        TT['theta_PI'][var_c, k] = TT['theta_totalm']         
        
        
        k+=1

        
        if (tail_t[td] == 1.):
            while (temp <= Ttest): 
                field = 0.0
                TT['warm'] = 1.0
                TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TT['beta'] = (1-(temp-273)/578.0)**0.43
 
                an.blockfind_TT(temp, field, afzero, V, TT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/4.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                TT['warm'] = 0.0
                TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TT['beta'] = (1-(temp-273)/578.0)**0.43
                an.blockfind_TT(temp, field, afzero, V, TT)  

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/4.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1       
        
            temp = temp + tempstep1 

        
            temp_r = 300.1
            TT['beta'] = (1-(temp_r-273)/578.0)**0.43
            an.blockfind_TT(temp_r, field, afzero, V, TT)
            V['end_mag'] = 1.0
            field = 0.0

            an.blockfind_TT(temp_r, field, afzero, V, TT) 
        
            TT['mag_tail'][var_c, td] = TT['totalm'] 

            V['end_mag'] = 0.0
            TT['temp_tail'][var_c, td] = Ttest

            TT['temp_PI'][var_c, k] = Ttest + 0.3
            TT['mag_PI'][var_c, k] = TT['totalm']
            TT['phi_PI'][var_c, k] = TT['phi_totalm']       
            TT['theta_PI'][var_c, k] = TT['theta_totalm']             
            
            k+=1
            t+=1

        td += 1
        Ttest = Ttest_arr[td]

    V['end_mag'] = 0.0    

    TT['len_a_trm_demag'][var_c] = td 
    field = V['field']

    j = var_c 
    TT['afstore'] = 0.0

    pl.TRM_thermal_demag(TT, SC, V,var_c) 

    f = open('{}\{}_TRM_arai.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_f' + "\t" 'NRM_r' + "\t" + 'pTRM' + "\t" + 'm_2' + '\n')
    for i in range(int(TT['len_a_trm_demag'][var_c])):
        f.write(str(TT['Ttest_list'][var_c, i]) + "\t" + str(TT['Ttest_list'][var_c, i]) + "\t" + str(TT['NRM_r'][var_c][i]) + "\t" + str(TT['pTRM'][var_c][i]) + "\t" + str(TT['M_2'][var_c][i]) + "\n")
    f.close()
	
    f = open('{}\{}_ptrm_TRM.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_ptrm' + "\t" 'NRM_r' + "\t" + 'M3' + "\t" + 'ptrm' + "\t" + 'ptrm tail temp'+ "\t" + 'tail nrm' + '\n')
    for i in range(int(TT['len_a_trm_demag'][var_c])):
        f.write(str(TT['temp_heat'][var_c, i]) + "\t" + str(TT['temp_check'][var_c, i]) + "\t" + str(TT['NRM_check'][var_c][i]) + "\t" + str(TT['pTRM_M3'][var_c][i]) + "\t" + str(TT['pTRM_check'][var_c][i]) + "\t" + str(TT['temp_tail'][var_c][i]) + "\t" + str(TT['mag_tail'][var_c][i]) +  "\n")
    f.close()	
	
	
    f = open('{}\{}_TRM_PI.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'mag' + "\t" + 'phi' + "\t" + 'theta' + '\n')
    for i in range(k):
        f.write(str(TT['temp_PI'][var_c, i]) + "\t" + str(TT['mag_PI'][var_c, i]) + "\t" + str(TT['phi_PI'][var_c,i]) + "\t" + str(TT['theta_PI'][var_c,i]) + "\n")
    f.close()    
    
    
    TT['hys'] = copy.deepcopy(I['hys'])

    eglip=0.54
    hf=(10000.**(0.54))*(10.**(-0.52)) 
    eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)

    afone = 1
    afzero = 0

    blockper = 0.0
    CT['blockper'] = blockper
    ac = 1.
    CT['hcstore'] = np.zeros(num_hyss)
    CT['histore'] = np.zeros(num_hyss)
    CT['unblocked'] = np.zeros(num_hyss)

    tm = 0.2
    CT['tm'] = tm

    final_R = np.zeros(num_hyss)

    CT['countiold'] = num_hyss 
    CT['blocktemp'] = np.zeros(num_hyss)
    CT['boltz'] = np.zeros(num_hyss)
    CT['blockg'] = np.zeros(num_hyss)
    CT['totalm'] = 0
    CT['sir'] = 0
    CT['aftotalm'] = 0
    CT['warm'] = 0.0
    CT['heating'] = 0.0
    CT['afstore'] = 0.0

    demag_field = CT['demag_field']

    field = V['field']
    temp = tempmin + 0.1 
    ms=ms0*(1-(tempt-273)/578.0)**0.43 

    tm = 0.2 
    CT['tm'] = tm
    ac = 1.

    CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
    CT['beta'] = (1.-(temp-273.)/578.0)**0.43

    CT['ms'] = ms0*CT['beta']

    CT['temp'] = temp

    CT['sense'] = np.ones(num_hyss)

    rate = 1 
    t =0 

    CT['rate'] = rate

    afswitch = afzero
    CT['hys'] = copy.deepcopy(I['hys']) 
    CT['angles'] = copy.deepcopy(I['angles'])     
    
    hys = np.copy(CT['hys'])
    V['end_mag'] = 0.0
    Ro = 1E-09 #nucleation radius 
    prop = np.zeros((num_hyss,12))
    prop[:,9] = ms*mu0*hys[:,9] #eo for constant de/dv 
    prop[:,0] = hys[:,10] #Vf
    prop[:,1] = (3.*prop[:,0]/(4.*pi))**(1./3.) #Rf 
    final_R = prop[:,1]
    prop[:,2] = (prop[:,1] - Ro)/g #growth time in seconds
    maxt = np.max(prop[:,2]) #max growth time 
    prop[:,3] = (maxt- prop[:,2])#nucleation time for each 

    CT['prop'] = np.copy(prop)

    #CRM acquisition

    t = 0.
    tstep = maxt/3000.

    CT['tstep'] = tstep

    tot_time_steps = (np.max(prop[:,2])+0.5*tstep)/tstep
    tot_time_steps = ceil(tot_time_steps)

    tm = 0
    aftotalm = 0
    CT['aftotalm'] = aftotalm
    CT['tm'] = tm 
    x=0 #loop over time steps

    ac = 1. 
    V['totalvol'] = sum(hys[:,10])
    while (t <= (np.max(prop[:,2]) + 0.5*tstep)): 

        prop = ge.find_tm(prop, num_hyss, t, g, Ro, eul, tau, tstep)

        
        CT['prop'] = prop
        an.blockfind_CT(t, field, afzero, V, CT)
        CT['crm_a'][var_c,x] = CT['totalm']
    
        CT['crm_phi_a'][var_c, x] = CT['phi_totalm']       
        CT['crm_theta_a'][var_c, x] = CT['theta_totalm']         
        
        CT['time_a'][var_c,x] = t
        CT['vol_a'][var_c,x] = np.mean(prop[:,5])
        CT['rad_a'][var_c,x] = np.mean(prop[:,4])
		
		
        x+=1
        if (t <= (0.4*np.max(prop[:,2]) + 0.5*tstep)):
            t+= 10*tstep
        else:
            t+= tstep 


    CT['len_a_crm'][var_c] = x
    t = t - tstep
    CT['prop'][:,10] = 60.0
    an.blockfind_CT(t, 0.0, afzero, V, CT)

    CT['beta'] = (1. - (temp - 273.)/578.0)**0.43

    j = var_c
    CT['max_crm'][var_c] = CT['totalm']
    prop = CT['prop']


    V['end_mag'] = 0.0            
    td = 0     
    fieldzero = 0.0

    CT['heating'] = 1.
   
    CT['hys'][:,5] = I['angles'][:,8]
    Ttest = Ttest_arr[td] 

    ac = 1.
    temp = tempmin + tempstep*10.
    p = 0
    t = 0
    k = 0
    while (Ttest < tempmax):
        CT['Ttest_list'][j,td] = Ttest
        while (temp <= Ttest): 
            CT['warm'] = 1.0
            CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            CT['beta'] = (1-(temp-273)/578.0)**0.43
            field = 0.0
            an.blockfind_C_T(temp, field, afzero, V, CT) 
            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1
        
        while (temp > tempmin): 
            CT['warm'] = 0.0
            CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            CT['beta'] = (1-(temp-273)/578.0)**0.43
            field = 0.0
            an.blockfind_C_T(temp, field, afzero, V, CT) 
            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1       

        
        temp = temp + tempstep1

        CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
        CT['beta'] = (1-(temp_r-273)/578.0)**0.43
        an.blockfind_C_T(temp_r, 0.0, afzero, V, CT)
		
		
        field = 0.0
        
        V['end_mag'] = 1.0
        an.blockfind_C_T(temp_r, 0.0, afzero, V, CT)
        V['end_mag'] = 0.0
        CT['temp_PI'][var_c, k] = Ttest
        CT['mag_PI'][var_c, k] = CT['totalm']
        CT['phi_PI'][var_c, k] = CT['phi_totalm']       
        CT['theta_PI'][var_c, k] = CT['theta_totalm']          
        k+=1
    
        CT['NRM_r'][var_c, td] = CT['totalm'] 

        if (ptrm_t[td] == 1.): 

            CT['temp_heat'][var_c, td] = Ttest 
            CT['temp_check'][var_c, td] = Ttest_arr[td-2]
            while (temp <= Ttest_arr[td-2]): 
                CT['reheat'] = 'yes'
                CT['warm'] = 1.0
                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                CT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                CT['beta'] = beta
                field = CT['demag_field']
                an.blockfind_C_T(temp, field, afzero, V, CT) 
  
                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                CT['warm'] = 0.0
                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                CT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                CT['beta'] = beta
                field = CT['demag_field']
                an.blockfind_C_T(temp, field, afzero, V, CT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1  

            temp = temp + tempstep1

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            CT['aconst'] = aconst
            beta= (1.-(temp_r-273.)/578.0)**0.43
            CT['beta'] = beta
			
            an.blockfind_C_T(temp_r, field, afzero, V, TT)

            V['end_mag'] = 1.0

            field = 0.0
            an.blockfind_C_T(temp_r, field, afzero, V, CT) 

            V['end_mag'] = 0.0
            ptrm = CT['totalm']
			
            CT['NRM_check'][var_c,td] = CT['NRM_r'][var_c, td]
            CT['pTRM_M3'][var_c, td] = ptrm

            CT['pTRM_check'][var_c, td] = ptrm - CT['NRM_r'][var_c, td] 
			
            CT['temp_PI'][var_c, k] = Ttest_arr[td-2] + 0.2
            CT['mag_PI'][var_c, k] = CT['totalm']
            CT['phi_PI'][var_c, k] = CT['phi_totalm']       
            CT['theta_PI'][var_c, k] = CT['theta_totalm']              
            
            k+=1
			
			
            p +=1        
		
        while (temp <= Ttest):
            CT['warm'] = 1.0
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            CT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            CT['beta'] = beta
            field = CT['demag_field']
            an.blockfind_C_T(temp, field, afzero, V, CT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1
        
        while (temp > tempmin): 
            CT['warm'] = 0.0
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            CT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            CT['beta'] = beta
            field = CT['demag_field']
 
            an.blockfind_C_T(temp, field, afzero, V, CT) 
            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1    


        temp = temp + tempstep1
        
        aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
        CT['aconst'] = aconst
        beta= (1.-(temp_r-273.)/578.0)**0.43
        CT['beta'] = beta
        an.blockfind_C_T(temp_r, field, afzero, V, CT)
        V['end_mag'] = 1.0
        field = 0.0
        an.blockfind_C_T(temp_r, field, afzero, V, CT)
        V['end_mag'] = 0.0
        CT['M_2'][var_c, td] = CT['totalm']
        CT['pTRM'][var_c, td] = CT['M_2'][var_c, td] - CT['NRM_r'][var_c, td] 
		
        CT['temp_PI'][var_c, k] = Ttest + 0.1
        CT['mag_PI'][var_c, k] = CT['totalm']
        CT['phi_PI'][var_c, k] = CT['phi_totalm']       
        CT['theta_PI'][var_c, k] = CT['theta_totalm']          
        
        k+=1		
		
        if (tail_t[td] == 1.):
            while (temp <= Ttest): 
                CT['warm'] = 1.0
                field = 0.0
                CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                CT['beta'] = (1-(temp-273)/578.0)**0.43

                an.blockfind_C_T(temp, field, afzero, V, CT) 
                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                CT['warm'] = 0.0
                CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                CT['beta'] = (1-(temp-273)/578.0)**0.43
                an.blockfind_C_T(temp, field, afzero, V, CT) 
                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1        
        
            temp = temp + tempstep1 

        
            temp_r = 300.1
            CT['beta'] = (1-(temp_r-273)/578.0)**0.43
            an.blockfind_C_T(temp_r, field, afzero, V, CT)
            V['end_mag'] = 1.0
            field = 0.0

            an.blockfind_C_T(temp_r, field, afzero, V, CT) 
      
            CT['mag_tail'][var_c, td] = CT['totalm'] 

            V['end_mag'] = 0.0
            CT['temp_tail'][var_c, td] = Ttest
			
            CT['temp_PI'][var_c, k] = Ttest + 0.3
            CT['mag_PI'][var_c, k] = CT['totalm']
            CT['phi_PI'][var_c, k] = CT['phi_totalm']       
            CT['theta_PI'][var_c, k] = CT['theta_totalm']              
            
            k+=1
			
            t+=1		
		
        td += 1
        Ttest = Ttest_arr[td]


    field = V['field']
    CT['len_a_trm_demag'][var_c] = td 
    CT['hys'] = copy.deepcopy(I['hys'])
    CT['sirm'] = np.copy(SC['sirm'])
    pl.CRM_thermal_demag(CT, SC, V,var_c) 
    
    pl.TRM_CRM_thermal_demag(TT, CT, SC, V, var_c)
    pl.plot_CRM_acquired_time(V, CT, var_c) #plot CRM acquired at that variable value
    pl.plot_TRM_acquired(V, TT, var_c) #plot TRM acquired at that variable value
    
    pl.NRM_pTRM(CT, TT, V, var_c) #plot NRM vs pTRM for CRM and TRM
    pl.TRM_arai_plot(TT,V,var_c) #plot TRM arai plot
    pl.CRM_arai_plot(CT,V,var_c) #plot TRM arai plot
    
    ac = 1.
    

    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    
    f= open('{}\{}_{}_prop.txt'.format(dire,variable_change[var_c], var_c), 'w')
    f.write('mean x' + "\t" + str(mu_x) + '\n')
    f.write('max x' + "\t" + str(xmax) + '\n')
    f.write('variance x' + "\t" + str(variance_x) + '\n')
    f.write('stdev x' + "\t" + str(stdev_x) + '\n')
    f.write('stdev y' + "\t" + str(stdev_y) + '\n')
    f.write('mean int field' + "\t" + str(V['mean_int_field'][var_c]) + '\n')    
    f.write('mean y' + "\t" + str(mu_y) + '\n')
    f.write('max y' + "\t" + str(ymax) + '\n')
    f.write('variance y' + "\t" + str(variance_y) + '\n')
    f.write('num hyss in remamance zone' + "\t" + str(V['num_hyss']) + '\n')
    f.write('growth rate' + "\t" + str(g) + '\n')
    f.write('applied field' + "\t" + str(V['field']) + '\n')

    f.write('variable adjusting' + "\t" + str(V['variable_c']) + '\n')
    f.write('variable adjusting value' + "\t" + str(V['variable_change'][var_c]) + '\n')
    f.write('phi_field_2' + "\t" + str(phi_field_2) + '\n')
    f.write('theta_field_2' + "\t" + str(theta_field_2) + '\n')    
    f.close()

    f = open('{}\{}_CRM_arai.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_f' + "\t" 'NRM_r' + "\t" + 'pTRM' + "\t" + 'M_2' + '\n')
    for i in range(int(CT['len_a_trm_demag'][var_c])):
        f.write(str(CT['Ttest_list'][var_c, i]) + "\t" + str(CT['Ttest_list'][var_c, i]) + "\t" + str(CT['NRM_r'][var_c][i]) + "\t" + str(CT['pTRM'][var_c][i]) + "\t" + str(CT['M_2'][var_c][i]) + "\n")
    f.close()
    

	
    f = open('{}\{}_CRM_PI.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'mag' + "\t" + 'phi' + "\t" + 'theta' + '\n')
    for i in range(k):
        f.write(str(CT['temp_PI'][var_c, i]) + "\t" + str(CT['mag_PI'][var_c, i]) + "\t" + str(CT['phi_PI'][var_c,i]) + "\t" + str(CT['theta_PI'][var_c,i]) + "\n")
    f.close()	
	
    f = open('{}\{}_ptrm_CRM.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_ptrm' + "\t" 'NRM_r' + "\t" + 'M3' + "\t" + 'ptrm' + "\t" + "\t" + 'ptrm tail temp'+ "\t" + 'tail nrm' + '\n')
    for i in range(int(CT['len_a_trm_demag'][var_c])):
        f.write(str(CT['temp_heat'][var_c, i]) + "\t" + str(CT['temp_check'][var_c, i]) + "\t" + str(CT['NRM_check'][var_c][i]) + "\t" + str(CT['pTRM_M3'][var_c][i]) + "\t" + str(CT['pTRM_check'][var_c][i]) +  "\t" + str(CT['temp_tail'][var_c][i]) + "\t" + str(CT['mag_tail'][var_c][i]) + "\n")
    f.close()		
    """
    f = open('{}/{}_TRM_blockper.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'trm' + "\t" + 'trm_phi' + "\t" + 'trm_theta' + "\t" + 'blockper' + '\n')
    for i in range(int(ST['len_a_trm'][var_c])):
        f.write(str(ST['temp_a'][var_c, i]) + "\t" + str(ST['trm_a'][var_c][i]) + "\t" + str(ST['trm_phi_a'][var_c][i]) + "\t" + str(ST['trm_theta_a'][var_c][i]) + "\t" + str(ST['blockper_a'][var_c][i]) + "\n")
    f.close()
	
    f = open('{}/{}CRM_blockper.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('time' + "\t" + 'crm' + "\t" + 'crm_phi' + "\t" + 'crm_theta' + "\t" + 'blockper' + '\n')
    for i in range(int(SC['len_a_crm'][var_c])):
        f.write(str(SC['time_a'][var_c, i]) + "\t" + str(SC['crm_a'][var_c][i]) + "\t" + str(SC['crm_phi_a'][var_c][i]) + "\t" + str(SC['crm_theta_a'][var_c][i]) + "\t" + str(SC['blockper_a'][var_c][i]) + "\n")
    f.close()
    """

    f= open('{}\{}_AF_demag.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('field step' + "\t" + 'TRM' + "\t" + 'phi_TRM' + "\t" + 'theta_TRM' + "\t" + 'CRM' + "\t" + 'phi_CRM' + "\t" + 'theta_CRM' + "\t" + 'SIRM_T' + "\t" + 'phi_SIRM_T' + "\t" + 'theta_SIRM_T' + "\t" + 'SIRM_C' + "\t" + 'phi_SIRM_C' + "\t" + 'theta_SIRM_C' + '\n')
    for i in range(int(SC['cntfield'])):
        f.write(str(SC['AF_steps'][i]) + "\t" + str(ST['afmag'][var_c][i]) + "\t" + str(ST['afmag_phi'][var_c][i]) + "\t" + str(ST['afmag_theta'][var_c][i]) + "\t" + str(SC['afmag'][var_c][i]) + "\t" + str(SC['afmag_phi'][var_c][i]) + "\t" + str(SC['afmag_theta'][var_c][i])  + "\t" + str(ST['sirm'][var_c][i]) +  "\t" + str(ST['sirm_phi'][var_c][i]) + "\t" + str(ST['sirm_theta'][var_c][i]) + "\t" + str(SC['sirm'][var_c][i]) + "\t" + str(SC['sirm_phi'][var_c][i]) + "\t" + str(SC['sirm_theta'][var_c][i]) + "\n")
    f.close()

    var_c = var_c +1 



f = open('{}\max_mag.txt'.format(dire), 'w')
f.write('variable value' + "\t" + 'max TRM' + "\t" + 'max TRM phi' + "\t" + 'max TRM theta' + "\t" + 'max CRM' + "\t" + 'max CRM phi' + "\t" + 'max CRM theta' + "\t" + ' max SIRM_T' + '\t' + 'max SIRM_T phi' + "\t" + 'max SIRM_T theta' + "\t" + 'max_SIRM_C' + "\t" + 'max_SIRM_C phi' + "\t" + 'max SIRM_C theta' + '\n')
for var_c in range(int(V['len_var'])):
    f.write(str(V['variable_change'][var_c]) + "\t" + str(ST['max_trm'][var_c]) + "\t" + str(ST['max_trm_phi'][var_c]) + "\t" + str(ST['max_trm_theta'][var_c]) + "\t" + str(SC['max_crm'][var_c]) + "\t" + str(SC['max_crm_phi'][var_c]) + "\t" + str(SC['max_crm_theta'][var_c]) + "\t" + str(ST['sirm'][var_c][0]) + "\t" + str(ST['sirm_phi'][var_c][0]) + "\t" + str(ST['sirm_theta'][var_c][0]) + "\t" + str(SC['sirm'][var_c][0]) + "\t" + str(SC['sirm_phi'][var_c][0]) + "\t" + str(SC['sirm_theta'][var_c][0]) + "\n")

f.write(str("--- %s seconds ---" % (time.time() - start_time)))	
f.close()


pl.CRM_TRM_var(CT, TT, V)
pl.SIRM_var(CT, TT, V)
pl.plot_ratios(CT, TT, V)
end = time.time()



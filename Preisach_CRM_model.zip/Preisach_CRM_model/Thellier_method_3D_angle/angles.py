#functions for 3D angle code 
from numba import jit
import numpy as np
from scipy.linalg import lstsq
from matplotlib.figure import figaspect
from math import acos, pi, degrees, sin, cos, sqrt, log, log10, tanh
from scipy.interpolate import interp2d
import random
import numpy as np


import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import lstsq
from numpy.polynomial.polynomial import polyfit
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
import matplotlib as matplotlib
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
from scipy.interpolate import griddata

#constant variables 
mu0 = 4*pi*1e-7
ms0 = 491880.5
kb = 1.3806503e-23
tau = 1e-9
roottwohffield = 2**(0.5)  


eglip=0.54
hf=(10000**(0.54))*(10**(-0.52)) 
eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)
affield = 0
affmax = 0.0
af_step_max = 0.0
flatsub=0
flat=0


afone = 1
afzero = 0



#blocking location in 3D case
@jit(nopython = True)
def block_loc_T(var_1, hys, angles, blockg, boltz, unblocked):

     #unpack variables from input array

    num_hyss = int(var_1[0])
    beta = float(var_1[1])
    blockper = float(var_1[2])
    temp = float(var_1[3])
    aconst = float(var_1[4])
    ms = float(var_1[5])
    rate = float(var_1[6])    
    tempmin = float(var_1[7])
    field = float(var_1[8])
    tm = float(var_1[9])
    end_mag = float(var_1[10])
    heating  = float(var_1[11])
    warm = float(var_1[12])
    

    tau = 1e-9
    kb = 1.3806503e-23 
    roottwohffield = 2**(0.5)
    hfstore = np.zeros((num_hyss))
    histore = np.zeros((num_hyss))    
    hcstore = np.zeros((num_hyss))   
    blocktemp = np.zeros((num_hyss))
    i=0 

    for i in range(num_hyss):

        phitemp=((sin(hys[i,5])**(2./3.))+(cos(hys[i,5])**(2./3.)))**(-3./2.)          
        hc=(sqrt(2))*(hys[i,9]*beta)       
        hcstore[i] = hc/(sqrt(2)) 

        hi = hys[i,1]*beta*blockper 
        histore[i] = hi/(sqrt(2)) 
    
        g=0.86+1.14*phitemp

        h_hs = field - histore[i]
        v_co = (1 - ((abs(h_hs))/(hys[i,9]*beta)))

        if (v_co <= 0):
            v_co = 0.00001
        v_act_c = hys[i,10]*v_co
 
    
        hf = (kb*temp)/(ms*mu0*v_act_c)
        hfstore[i] = hf 

    
        dt = 10.
        r = 1.
        if (rate == 1): 
            
    
            r = (1./aconst)*(temp-tempmin) 

            tm = (temp/r)*(1 - (temp/(578+273)))/log((2*temp)/(tau*r)*((1. - (temp/(578+273)))))

            
 
            if (tm == 0.0): 
                tm = 60.0
        if (end_mag == 1.0):
            tm = 60.0

        ht = (roottwohffield)*hf*(log(tm/tau)) 

        if (temp < 0):

            print('ht', ht*mu0*1000, 'hf', hf*mu0*1000, '0.54' ,hc*mu0*1000, tm) 

        bracket = 1-(2*ht*phitemp/hc)**(1/g)
        
        hiflipplus = hc*bracket+field*(roottwohffield) 
    
        hiflipminus=-hc*bracket+field*(roottwohffield) 

    
        if (hc >= (2*ht*phitemp)): 

            if ((hi > hiflipminus) and (hi < hiflipplus)): 
    
                
                if ((blockg[i] == 0) or (blockg[i] == 2) or (blockg[i] == -2)): 

                    if (hi >= (field*roottwohffield)): 

                        blocktemp[i] = -1

                    else:

                        blocktemp[i] = 1

                elif (blockg[i] == -1): 

                    blocktemp[i] = -1
                  
                 

                elif (blockg[i] == 1):
 
                    blocktemp[i] = 1
                    
                else:

                    print(blockg[i], blocktemp[i]) 
                    print('----', i)

            elif (hi >= hiflipplus):

                blocktemp[i] = -2
                if (heating == 1.) and (warm == 1.):
                    boltz[i] = 0.0
                    unblocked[i] = 1.

            else:

                blocktemp[i] = 2
                if (heating == 1.) and (warm == 1.):
                    boltz[i] = 0.0
                    unblocked[i] = 1.

        else: 
            #if (test_mom == 1):
                #   print('hys', i, 'hc <  2*ht*phitemp')
            
    
            if ((hi < hiflipminus) and (hi > hiflipplus)): 
                
                blocktemp[i] = 0                
                boltz[i] = 0.0
                if (heating == 1.) and (warm == 1.):
                    boltz[i] = 0.0
                    unblocked[i] = 1.

            else: 
                if (hi >= hiflipminus):

                    blocktemp[i] = -2
                    if (heating == 1.) and (warm == 1.):
                        boltz[i] = 0.0
                        unblocked[i] = 1.

                else:

                    blocktemp[i] = 2
                    if (heating == 1.) and (warm == 1.):
                        boltz[i] = 0.0
                        unblocked[i] = 1.


    return hfstore, histore, boltz, blocktemp, angles, unblocked

#Calculate magnetisation in 3D
@jit(nopython = True)
def block_val_T(hys, angles, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, unblocked, heating):

    totalm = 0.0
    totalmx = 0.0
    totalmy = 0.0
    totalmz = 0.0 
    totalmoment = 0
    i=0
    blockper = 0.
    
    for i in range(num_hyss):

        blockg[i] = blocktemp[i]
        absblockg = abs(blockg[i])

        if (absblockg == 1): 
            if (boltz[i] < 0.00000001) and (boltz[i] > -0.000000001): 
     

                boltz[i] = tanh((field - histore[i])/hfstore[i])
                
                if (afswitch == 1):

                    boltz[i] = 0.

               
        if (blockg[i] == -2):
            

            moment = -0 

        elif (blockg[i] == 2):

            moment = 0

        else:

            moment = blockg[i] 


        #AF demag calc
      
        if (afswitch == 1): #afswtich given in function, 1 or 0
            print('shouldnt have afswitch == 1')

            hi = histore[i]*(sqrt(2))

            hc = (sqrt(2))*(hys[i,9]*beta)*(((sin(hys[i,6])**(2./3.))+(cos(hys[i,6])**(2./3.)))**(-3./2.))
    
            af = afstore/(1000*mu0) 
        
            
            if (hi >=0) and (hi > (hc-af)): 

                moment = 0
               
                boltz[i] = 0
                blockg[i] = -2
            
        
            if (hi <= 0) and (hi < (-hc + af)):

                moment = 0
                blockg[i] = 2

                boltz[i] = 0

    
        if (heating == 1.) and (unblocked[i] == 1.):
            angles[i,2] = angles[i,4]
        totalmx = totalmx +(abs(moment)*beta*(boltz[i])*((hys[i,3]*hys[i,10])/max_total))*angles[i,2]*angles[i,5]
        totalmy = totalmy + (abs(moment)*beta*(boltz[i])*((hys[i,3]*hys[i,10])/max_total))*angles[i,2]*angles[i,6]
        totalmz = totalmz + (abs(moment)*beta*(boltz[i])*((hys[i,3]*hys[i,10])/max_total))*angles[i,2]*angles[i,7]   

        if (beta < 0):
            print('print beta < 0')

        if ( hfstore[i] < 0):
            print('hf <0')

        if (blockg[i] == -1) or (blockg[i] == 1):
             moment_block = 1
        else:
            moment_block = 0
		
        blockper=blockper+ ((abs(moment_block))*hys[i,10]*hys[i,3]) 

        totalmoment=totalmoment+moment
        
    if (blockper != 0):

        blockper= (blockper)/(vol_rem)
    else:
        blockper = 1E-15

    totalm = sqrt((totalmx)**2 + (totalmy)**2 + (totalmz)**2)

    if (totalm != 0):
        phi_totalm = np.arccos(totalmz/totalm) 
    else:
        phi_totalm = 0.0
        
    if (totalmx != 0):    
        theta_totalm = np.arctan(totalmy/totalmx) 
    elif (totalmy > 0):
        theta_totalm = pi/2.
    elif (totalmy < 0):
        theta_totalm = pi/2 + pi
    else:
        theta_totalm = 0.

    return blockper, totalm, boltz, blockg, phi_totalm, theta_totalm

#blockfind for TRM case 
def blockfind_TT(temp, field, afswitch, V, TT):
    hys = TT['hys']
    num_hyss = V['num_hyss']
    hcstore = TT['hcstore']
    histore = TT['histore']
    beta = TT['beta']
    rate = TT['rate']
    aconst = TT['aconst']
    tempmin = V['tempmin']
    sense = TT['sense']
    angles = TT['angles']    
    unblocked = TT['unblocked'] 
    
    max_total_a = hys[:,10]*hys[:,3]	
    max_total = sum(max_total_a)
    vol_rem = V['vol_rem']
	
    tm = TT['tm'] 

    hfstore = np.zeros(num_hyss)
	
    tempmax = V['tempmax'] 
   
    ms = ms0*beta 
    conv=(mu0*1000.)/(sqrt(2.))

    blockper = TT['blockper'] 
    countiold = TT['countiold']

    blocktemp = TT['blocktemp'] 
    boltz = TT['boltz']
    blockg = TT['blockg']

    totalm = TT['totalm']
    heating = TT['heating']
    end_mag = V['end_mag']
    afstore = TT['afstore']
    warm = TT['warm']

    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating, warm))

    hfstore, histore, boltz, blocktemp, angles, unblocked = block_loc_T(var_1, hys, angles, blockg, boltz, unblocked)
  
    blockper, totalm, boltz, blockg, phi_totalm, theta_totalm = block_val_T(hys, angles, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, unblocked, heating)


    TT['aftotalm'] = totalm
    TT['sir'] = totalm
    TT['blockper'] = blockper
    TT['countiold'] = countiold 
    TT['blocktemp'] = blocktemp
    TT['boltz'] = boltz
    TT['blockg'] = blockg
    TT['totalm'] = totalm
    TT['tm'] = tm
    TT['sense'] = sense
    TT['angles'] = angles
    TT['phi_totalm'] = phi_totalm
    TT['theta_totalm'] = theta_totalm  
    TT['unblocked'] = unblocked  

    return 

#location of blocking for CRM case
@jit(nopython = True)
def block_loc_C(var_1, hys, prop, angles, blockg, boltz):

    num_hyss = int(var_1[0])
    beta = float(var_1[1])
    blockper = float(var_1[2])
    temp = float(var_1[3])
    t = float(var_1[4])
    tstep = float(var_1[5])
    rate = float(var_1[6])    
    field = float(var_1[7])
    tm = float(var_1[8])
    end_mag = float(var_1[9])

    tau = 1e-9
 
    roottwohffield = 2**(0.5)
    hfstore = np.zeros((num_hyss))
    histore = np.zeros((num_hyss))    
    hcstore = np.zeros((num_hyss))   
    blocktemp = np.zeros((num_hyss))
    i=0 
    for i in range(num_hyss):
        if (t >= (prop[i,3] + (0.5*tstep))):

            phitemp=((sin(hys[i,5])**(2./3.))+(cos(hys[i,5])**(2./3.)))**(-3./2.)             
            hc=(sqrt(2))*(hys[i,9]*beta) 
            
            hcstore[i] = hc/(sqrt(2))
        
            
            hi = hys[i,1]*beta*blockper 
            
    
            histore[i] = hi/(sqrt(2))

            g=0.86+1.14*phitemp
    
            h_hs = field - histore[i]
            v_co = (1 - ((abs(h_hs))/(hys[i,9]*beta)))
            if (v_co <= 0):
                v_co = 0.00001               
            
            v_act_c = prop[i,5]*v_co

            hf = hys[i,11]*(1/(v_act_c))
        
            hfstore[i] = hf

            if (rate == 1):
                
                tm= prop[i,10]
                
                if (tm == 0.0): 
                    tm = 60.0
    
   
            
            if (end_mag == 1.0):
                tm = 60.0
            ht = (roottwohffield)*hf*(log(tm/tau)) 
            
            bracket = 1-(2*ht*phitemp/hc)**(1/g)
            
            hiflipplus = hc*bracket+field*(roottwohffield) 
    
            hiflipminus=-hc*bracket+field*(roottwohffield) 
            trialtemp=0

            if (hc >= (2*ht*phitemp)):

                if ((hi > hiflipminus) and (hi < hiflipplus)): 

                    if (blockg[i] == 0) or (blockg[i] == 2) or (blockg[i] == -2): 
                        
                        if (hi >= (field*roottwohffield)): 
                            
                            blocktemp[i] = -1
                            
                        else:

                            blocktemp[i] = 1 
                            
                    elif (blockg[i] == -1): 
                        
                        blocktemp[i] = -1
                

                    elif (blockg[i] == 1):
                        blocktemp[i] = 1
                        
                        
                    else:

                        print('error')


                elif (hi >= hiflipplus):

                    blocktemp[i] = -2

                    
                else:

                    blocktemp[i] = 2


            else: 

        
                if ((hi < hiflipminus) and (hi > hiflipplus)): 

                    blocktemp[i] = 0

                else: 
                    if (hi >= hiflipminus):

                        blocktemp[i] = -2

                    else:

                        blocktemp[i] = 2


            if (temp < trialtemp):

                print('blocktemp', blocktemp[i])
                
    return hfstore, histore, boltz, blocktemp, angles

##function to determine percentage alignment with the field if blocked at this time step 
@jit(nopython = True)
def block_val_C(hys, prop, angles, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, t, tstep):

    totalm = 0.0
    totalmx = 0.0
    totalmy = 0.0
    totalmz = 0.0    
    totalmoment = 0

    i=0

    blockper = 0.
    for i in range(num_hyss):

        
        blockg[i] = blocktemp[i]
        absblockg = abs(blockg[i])
        if (t >= (prop[i,3] + (0.5*tstep))):
           
            if (absblockg == 1): #if blockg 1 or -1
                if (boltz[i] < 0.00000001) and (boltz[i] > -0.000000001): #only zero

                    boltz[i] = tanh((field - histore[i])/hfstore[i])
                    if (afswitch == 1):

                        boltz[i] = 0.

                   
            if (blockg[i] == -2):

                moment = -0 
            elif (blockg[i] == 2):

                moment = 0
            else:

                moment = blockg[i]


            
            
            if (afswitch == 1): 

                hi = histore[i]*(sqrt(2))
                hc = (sqrt(2))*(hys[i,9]*beta)*(((sin(hys[i,6])**(2./3.))+(cos(hys[i,6])**(2./3.)))**(-3./2.))
        
                af = afstore/(1000*mu0) 
                if (hi >= 0) and (hi > (hc-af)): 
                    moment = 0
                    blockg[i] = -2

                    boltz[i] = 0.
                if (hi <= 0) and (hi < (-hc + af)):
                    moment = 0
                    blockg[i] = 2

                    boltz[i] = 0.0
            totalmx += (abs(moment)*beta*(boltz[i])*((hys[i,3]*prop[i,5])/max_total))*angles[i,2]*angles[i,5]
            totalmy += (abs(moment)*beta*(boltz[i])*((hys[i,3]*prop[i,5])/max_total))*angles[i,2]*angles[i,6]
            totalmz += (abs(moment)*beta*(boltz[i])*((hys[i,3]*prop[i,5])/max_total))*angles[i,2]*angles[i,7]         
         

            if (beta < 0):
                print('print beta < 0')

            if ( hfstore[i] < 0):
                print('hf <0')

            if (blockg[i] == -1) or (blockg[i] == 1):
                moment_block = 1
            else:
                moment_block = 0
		
            blockper=blockper+ ((abs(moment_block))*prop[i,5]*hys[i,3]) 
            totalmoment=totalmoment+moment
    totalm = sqrt((totalmx)**2 + (totalmy)**2 + (totalmz)**2)
    if (totalm != 0):
        phi_totalm = np.arccos(totalmz/totalm) 
    else:
        phi_totalm = 0.0
        
    if (totalmx != 0):    
        theta_totalm = np.arctan(totalmy/totalmx) 
    elif (totalmy > 0):
        theta_totalm = pi/2.
    elif (totalmy < 0):
        theta_totalm = pi/2 + pi
    else:
        theta_totalm = 0.
    

    if (blockper != 0.):
        blockper= (blockper)/(vol_rem)
    else:

        blockper = 1E-15
    return blockper, totalm, boltz, blockg, phi_totalm, theta_totalm


#CRM blockfind
def blockfind_SC(t, field, afswitch, V, SC): 
    totalvol = V['totalvol']

    hys = SC['hys']
    prop = SC['prop']
    
    angles = SC['angles']
    
    totalvol = sum(hys[:,10])
    max_total_a = prop[:,5]*hys[:,3]

    max_total_m_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_m_a)
	
    vol_rem = V['vol_rem']
	
    num_hyss = V['num_hyss']
    hcstore = SC['hcstore']
    histore = SC['histore']
    beta = SC['beta']
    rate = SC['rate']
    aconst = SC['aconst']
    tempmin = V['tempmin']
    tempstep = V['tempstep']
    sense = SC['sense']
    ms = SC['ms']
    tm = SC['tm'] 
    tstep = SC['tstep']
    
    temp = SC['temp']

   
    hfstore = np.zeros(num_hyss)
    

    conv=(mu0*1000)/(sqrt(2))

    blockper = SC['blockper'] 
    countiold = SC['countiold']
    blocktemp = SC['blocktemp'] 
    boltz = SC['boltz']
    blockg = SC['blockg']
    totalm = SC['totalm']
    end_mag = V['end_mag']
    afstore = SC['afstore']

    var_1 = np.array((num_hyss, beta, blockper, temp, t, tstep, rate, field, tm, end_mag))

    hfstore, histore, boltz, blocktemp, angles = block_loc_C(var_1, hys, prop, angles, blockg, boltz)
  
    blockper, totalm, boltz, blockg, phi_totalm, theta_totalm = block_val_C(hys, prop, angles, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, t, tstep)
           

    SC['aftotalm'] = totalm
    SC['sir'] = totalm
    SC['blockper'] = blockper
    SC['countiold'] = countiold 
    SC['blocktemp'] = blocktemp
    SC['boltz'] = boltz
    SC['blockg'] = blockg
    SC['totalm'] = totalm
    SC['tm'] = tm
    SC['sense'] = sense
    
    SC['angles'] = angles
    SC['phi_totalm'] = phi_totalm
    SC['theta_totalm'] = theta_totalm     

    return 
     

#function for blockfind CRM 
def blockfind_CT(t, field, afswitch, V, CT): 
    totalvol = V['totalvol']

    hys = CT['hys']
    prop = CT['prop']
    
    angles = CT['angles']
    
    totalvol = sum(hys[:,10])
    max_total_a = prop[:,5]*hys[:,3]

    max_total_m_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_m_a)
	
    vol_rem = V['vol_rem']
	
    num_hyss = V['num_hyss']
    hcstore = CT['hcstore']
    histore = CT['histore']
    beta = CT['beta']
    rate = CT['rate']
    aconst = CT['aconst']
    tempmin = V['tempmin']
    tempstep = V['tempstep']
    sense = CT['sense']
    ms = CT['ms']
    tm = CT['tm'] 
    tstep = CT['tstep']
    
    temp = CT['temp']

   
    hfstore = np.zeros(num_hyss)

    heating = CT['heating']
    

    conv=(mu0*1000)/(sqrt(2))

    blockper = CT['blockper'] 
    countiold = CT['countiold']
    blocktemp = CT['blocktemp'] 
    boltz = CT['boltz']
    blockg = CT['blockg']
    totalm = CT['totalm']
    end_mag = V['end_mag']
    afstore = CT['afstore']
    
    var_1 = np.array((num_hyss, beta, blockper, temp, t, tstep, rate, field, tm, end_mag))

    hfstore, histore, boltz, blocktemp, angles = block_loc_C(var_1, hys, prop, angles, blockg, boltz)
  
    blockper, totalm, boltz, blockg, phi_totalm, theta_totalm = block_val_C(hys, prop, angles, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, t, tstep)
           
        
    CT['aftotalm'] = totalm
    CT['sir'] = totalm
    CT['blockper'] = blockper
    CT['countiold'] = countiold 
    CT['blocktemp'] = blocktemp
    CT['boltz'] = boltz
    CT['blockg'] = blockg
    CT['totalm'] = totalm
    CT['tm'] = tm
    CT['sense'] = sense
    
    CT['angles'] = angles
    CT['phi_totalm'] = phi_totalm
    CT['theta_totalm'] = theta_totalm     

    return
     
  


#blockfind for Thellier on CRM
def blockfind_C_T(temp, field, afswitch, V, CT):
    hys = CT['hys']
    num_hyss = V['num_hyss']
    hcstore = CT['hcstore']
    histore = CT['histore']
    beta = CT['beta']
    rate = CT['rate']
    aconst = CT['aconst']
    tempmin = V['tempmin']
    sense = CT['sense']
    
   
    angles = CT['angles']
    heating = CT['heating']
    warm = CT['warm']
	

    max_total_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_a)
    vol_rem = V['vol_rem']

    
    tm = CT['tm'] 

    hfstore = np.zeros(num_hyss)

    ms = ms0*beta
    conv=(mu0*1000)/(sqrt(2))

    blockper = CT['blockper'] 
    countiold = CT['countiold']
    blocktemp = CT['blocktemp'] 
    boltz = CT['boltz']
    blockg = CT['blockg']
    oldblockg = blockg
    afstore = CT['afstore']
    unblocked = CT['unblocked']
    
    end_mag = V['end_mag']

    totalm = CT['totalm']
 
    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating, warm))

    hfstore, histore, boltz, blocktemp, angles, unblocked = block_loc_T(var_1, hys, angles, blockg, boltz, unblocked)
  
    blockper, totalm, boltz, blockg, phi_totalm, theta_totalm = block_val_T(hys, angles, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, unblocked, heating)

        
    CT['aftotalm'] = totalm
    CT['sir'] = totalm
    CT['blockper'] = blockper
    CT['countiold'] = countiold 
    CT['blocktemp'] = blocktemp
    CT['boltz'] = boltz
    CT['blockg'] = blockg
    CT['oldblockg'] = oldblockg 
    CT['totalm'] = totalm
    CT['tm'] = tm
    CT['sense'] = sense
    CT['angles'] = angles
    CT['phi_totalm'] = phi_totalm
    CT['theta_totalm'] = theta_totalm  
    CT['unblocked'] = unblocked  

    return
       

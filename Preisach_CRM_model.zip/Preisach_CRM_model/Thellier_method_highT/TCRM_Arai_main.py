#import functions
import BF_arai_AF_HT as bf
import general as ge
import plots as pl

#inport packages
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
import os as os
from math import pi, log, log10, ceil
import copy
import time 

start_time = time.time()

#variables not change 
tempt=300.
ms0 = 491880.5
mu0 = 4*pi*1e-7
kb = 1.3806503e-23
tau = 1e-9
roottwohffield = 2**(0.5)  
sumegli = 0.0
eglip=0.54
eglid=log(113*((31486**(-eglip))))+0.52
eglid=113*((31486**(-eglip)))
egliin = 5.4
eglip=egliin/10.0 
hf=(10000**(0.54))*(10**(-0.52))
eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)
tempt = 300
eul = 1.78107 #exp(eulers const)

#declare dictionaries 
V = {}
TC_A = {}
TC_T = {}
I = {}


V['name'] = 'PN2_HCRM' # input name of sample
V['variable_c'] = 'PN2_HCRM' # variable changing 

V['variable_change'] = np.array((623.15, 300.1))


len_var = len(V['variable_change'])
V['len_var'] = len_var
var_c =0 

#preisach parameters
mu_x = 0.02 # mean hc

ymax = 0.04 #max hi
variance_y = 0.000006*((0.001/0.01))**(2) #spread in y axis
variance_x = 0.00003 #spread in x axis

xmax = 0.04

#field parameters
minf = 50E-6
maxf = 150E-6
num_fields = 3.
fieldmax=maxf/mu0
fieldmin= minf/mu0 
fieldstep=(fieldmax-fieldmin)/num_fields 
field = 50E-6/mu0 
V['field'] = field

#number hysterons
num_hyss_pre = 500000 
V['num_hyss'] = num_hyss_pre

#temp parameters
tempmax=577.+273. # one degree less than Tc 
tempmin =300.
V['tempmin'] = tempmin

tempstep= 1.
V['tempstep'] = tempstep
#time constant in hours
ac = 1.

#CRM growth rate

g = 1E-13

TC_A['afstore'] = 0.
V['heating'] = 0.
TC_A['err_c'] = 0.0

TC_T['err_s'] = 0.0 
TC_T['err_t'] = 0.0
TC_A['err_t'] = 0.0
TC_T['err_c'] = 0.0
TC_A['err_s'] = 0.0

variable_change = V['variable_change']

current_directory = os.getcwd()
final_directory = os.path.join(current_directory, V['variable_c'])
if not os.path.exists(final_directory):
    os.makedirs(final_directory)
    
V['dir'] = final_directory

#arrays for tracking and plotting 

len_var = V['len_var']
TC_A['trm_a'] = np.zeros((len_var, 82000))
TC_A['len_a_trm'] = np.zeros(len_var)
TC_A['temp_a'] = np.zeros((len_var, 20000))
maxcrm = np.zeros((len_var))

TC_A['tcrm_a'] = np.zeros((len_var, 20000))
TC_A['len_a_tcrm'] = np.zeros((len_var))
TC_A['time_temp_a'] = np.zeros((len_var, 20000))

TC_A['max_tcrm'] = np.zeros((len_var))

#plot and track CRM part of TCRM acquisition
TC_A['crm_a'] = np.zeros((len_var, 20000))
TC_A['len_a_crm'] = np.zeros((len_var))
TC_A['time_a'] = np.zeros((len_var, 20000))
TC_A['vol_a'] = np.zeros((len_var, 20000))
TC_A['rad_a'] = np.zeros((len_var, 20000))


TC_A['max_crm'] = np.zeros((len_var))

#AF demag steps
TC_A['AF_steps'] = np.array([0.0, 2.5, 5., 7.5, 10, 12.5, 15., 17.5, 20., 25., 30., 35., 40., 45., 50., 55., 60., 65., 70., 80., 90., 100.])


#arrays for TCRM results
TC_A['cntfield'] = len(TC_A['AF_steps'])
cntfields = TC_A['cntfield']
TC_A['sirm'] = np.zeros((len_var, cntfields)) 

TC_A['afmag'] = np.zeros((len_var, cntfields)) 

TC_A['tcrm'] = np.zeros((len_var, cntfields))


t_t_check_TC_A = np.zeros((len_var, 305))


TC_A['Ttrm_a'] = np.zeros((len_var, 20000))
TC_A['len_a_Ttrm'] = np.zeros((len_var))
TC_A['Ttemp_a'] = np.zeros((len_var, 20000))


TC_A['Ttcrm_a'] = np.zeros((len_var, 20000))
TC_A['len_a_Ttcrm'] = TC_A['len_a_Ttrm']
TC_A['Ttime_a_t'] = np.zeros((len_var, 20000))
TC_A['max_tcrm_TC_T'] = np.zeros((len_var)) #max TCRM is max TRM 


TC_A['NRM_r'] = np.zeros((len_var, 100))
TC_A['pTRM'] = np.zeros((len_var, 100))
TC_A['M_2'] = np.zeros((len_var,100))

TC_A['demag_field'] = (50E-6)/mu0 
TC_A['len_a_Ttrm_demag'] = np.zeros((len_var))
TC_A['Ttest_list'] = np.zeros((len_var, 100)) 


TC_A['Tcrm_a'] = np.zeros((len_var, 1000))
TC_A['len_a_Tcrm'] = np.zeros((len_var))
TC_A['Ttime_a'] = np.zeros((len_var, 1000))

TC_A['temp_heat'] = np.zeros((len_var, 100))
TC_A['temp_check'] = np.zeros((len_var, 100))
TC_A['NRM_check'] = np.zeros((len_var, 100))
TC_A['pTRM_M3'] = np.zeros((len_var, 100))
TC_A['pTRM_check'] = np.zeros((len_var, 100))
TC_A['temp_tail'] = np.zeros((len_var, 100))
TC_A['mag_tail'] = np.zeros((len_var, 100))
TC_A['temp_PI'] = np.zeros((len_var, 100))
TC_A['mag_PI'] = np.zeros((len_var, 100))


V['mean_int_field'] = np.zeros((len_var))


var_c = 0

TC_A['num_blocking'] = np.zeros((int(len_var), 20000))

for var_c in range(len(V['variable_change'])):
    
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']

    temp_c = V['variable_change'][var_c]

    V['tempmax'] = temp_c 

    mu_y = 0.00
    xmax = 0.04
    mu_x = 0.02
    ymax = 0.006 
    stdev_y = 0.001
    variance_y = ((stdev_y)**2)
    stdev_x = 7E-3
    variance_x = (stdev_x)**2

	#Create grid and multivariate normal
	
    x = np.linspace(0,xmax,250)
    y = np.linspace(-ymax,ymax,250)
    X, Y = np.meshgrid(x,y)
    pos = np.empty(X.shape + (2,))
    pos[:, :, 0] = X; pos[:, :, 1] = Y
    rv = multivariate_normal([mu_x, mu_y], [[variance_x, 0], [0, variance_y]])
    z = rv.pdf(pos)


    TC_A['x'] = X
    TC_A['y'] = Y
    TC_A['z'] = z
 
    TC_T['x'] = X
    TC_T['y'] = Y
    TC_T['z'] = z
	
    I['x'] = X
    I['y'] = Y
    I['z'] = z

    ge.norm_z_HT(V, TC_A, TC_T, I, var_c)


    tempt = 300
    ms=ms0*(1-(tempt-273)/578.0)**0.43 
    tm = 0.2
    I['ms'] = ms
    I['tm'] = tm

    hys, num_pop = ge.pop_hys(num_hyss_pre, V, I) 


    I['hys'] = hys

    I,V = ge.blocked_hys(I,V)
    num_hyss = V['num_hyss'] 

    
    #TCRM AF demag model

    #define variables
    affield = 0
    affmax = 0.0
    af_step_max = 0.0
    flatsub=0
    flat=0

    afone = 1
    afzero = 0

    counttime_TC_A = 0
    TC_A['counttime'] = counttime_TC_A
    blockper = 0.0
    TC_A['blockper'] = blockper


	
    TC_A['boltz_t'] = np.zeros(20000)
    TC_A['blockper_t'] = np.zeros(20000)

    afmagstore_TC_A = np.zeros((100))
    negsirm_TC_A = np.zeros((100))
    afcount_TC_A = np.zeros(20000) 
    hcstore = np.zeros(num_hyss)
    TC_A['hcstore'] = hcstore
    histore = np.zeros(num_hyss)
    TC_A['histore'] = histore
    spacing = 1.1

    TRM_ac_hys_TC_A = []

    TC_A['countiold'] = num_hyss 

    blockg = np.zeros(num_hyss) 
    boltz = np.zeros(num_hyss)
    blocktemp = np.zeros(num_hyss) 
    af_step = TC_A['AF_steps']
    TC_A['blocktemp'] = blocktemp
    TC_A['boltz'] = boltz
    TC_A['blockg'] = blockg
    TC_A['totalm'] = 0
    TC_A['sir'] = 0
    TC_A['aftotalm'] = 0

    partvol = 0.0
    i=0 
    hctot = 0
    hitot=0
    ranvtot=0 
    switch=0
    countsf=0
    countsfnew=0
    tempvol=0.0 
    hicount=0
    temp= temp_c
    TC_A['temp'] = temp
    sense = np.ones(num_hyss)
    TC_A['sense'] = sense
    rate = 1 
    TC_A['rate'] = rate
    TC_A['totalblocktwo'] = 0
    TC_A['totalblock'] = 0
    TC_A['totalmoment'] = 0

    TC_A['timecount'] = np.zeros(20000)
    afswitch = afzero

    TC_A['hys'] = copy.deepcopy(I['hys']) 

    hys = TC_A['hys']
    tm = 0
    aftotalm = 0
    TC_A['aftotalm'] = aftotalm
    TC_A['tm'] = tm 
    track = 0

    #CRM part of TCRM
    ac = 1.
    #main CRM model
    final_R_TC_A = np.zeros(num_hyss) 

    beta= (1-((temp-273)/578.0))**0.43
    TC_A['beta'] = beta
    ms=ms0*beta
    TC_A['ms'] = ms
    tempmax = 577+273 
    aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax -tempmin))) 
    TC_A['aconst'] = aconst

    TC_A['hys'][:,11] = (kb*temp)/(mu0*ms)
    
    TC_A['temp'] = temp
    sense = np.ones(num_hyss) 
    TC_A['sense'] = sense

    rate = 1 

    t =0 

    Ro = 1E-09 #nucleation radius
    prop = np.zeros((num_hyss,12)) 
    prop[:,9] = ms*mu0*hys[:,9] #eo for constant de/dv 
    prop[:,0] = hys[:,10] #Vf
    prop[:,1] = (3*prop[:,0]/(4*pi))**(1./3.) #Rf 
    final_R = prop[:,1]
    prop[:,2] = (prop[:,1] - Ro)/g #growth time in seconds
    maxt = np.max(prop[:,2]) #max growth time 
    prop[:,3] = (maxt- prop[:,2])#nucleation time for each 

    TC_A['prop'] = prop
    TC_A['totalvol'] = sum(prop[:,0])

    #CRM acquisition
    V['end_mag'] = 0.0
    t = 0
    tstep = maxt/15000.
    TC_A['tstep'] = tstep

    tot_time_steps = (np.max(prop[:,2])+0.5*tstep)/tstep
    tot_time_steps = ceil(tot_time_steps)

    tm = 0
    aftotalm = 0
    TC_A['aftotalm'] = aftotalm
    TC_A['tm'] = tm 
    x=0 #loop over time steps
    field = V['field']
    t_b = 0

    while (t <= (np.max(prop[:,2]) + 0.5*tstep)): 

        prop = ge.find_tm(prop, num_hyss, t, g, Ro, eul, tau, tstep)


        TC_A['track'] = x
        TC_A['prop'] = prop
        bf.blockfind_TC_A(t, field, afzero, V, TC_A)

        TC_A['crm_a'][var_c,x] = TC_A['totalm'] 

        TC_A['time_a'][var_c,x] = t
        TC_A['vol_a'][var_c,x] = np.mean(prop[:,5])
        TC_A['rad_a'][var_c,x] = np.mean(prop[:,4])

        x+=1
        t_b +=1
        if (t <= (0.4*np.max(prop[:,2]) + 0.5*tstep)):
            t+= 500*tstep

          
        else:
            t+= tstep


    t = t - tstep 
    
    
    plt.scatter(TC_A['time_a'][var_c,:x], TC_A['num_blocking'][var_c,:x])
    plt.xlabel('time step')
    plt.ylabel('number blocking')
    plt.title('number blocking at each time step PW2 at: {}'.format(V['variable_change'][var_c]))
    plt.savefig('time_numblock_PW2__{}.png'.format(V['variable_change'][var_c]))
    plt.close()   

    plt.scatter(TC_A['time_a'][var_c,:x], TC_A['crm_a'][var_c,:x])
    plt.xlabel('time step')
    plt.ylabel('crm')
    plt.title('CRM acquisition PW2 at: {}'.format(V['variable_change'][var_c]))
    plt.savefig('crm_acquired_PW2_{}.png'.format(V['variable_change'][var_c]))
    plt.close()          
    
    
    
    TC_A['max_crm'][var_c] = TC_A['totalm'] 
    counttime_TC_A = TC_A['counttime'] 
    counttimecrm = counttime_TC_A
    TC_A['len_a_crm'][var_c] = x

    bf.blockfind_TC_A(t, field, afzero, V, TC_A)
    TC_A['blockper_t'][t_b] = TC_A['blockper']
    TC_A['boltz_t'][t_b] = sum(TC_A['boltz'])

    t_b +=1

    TC_A['tm_print'] = 0.

    if (temp == 300.1):
        temp = tempmin
    while (temp > tempmin): #cooling part of HCRM or TCMR acquisition

        beta= (1-(temp-273)/578.0)**0.43
        TC_A['beta'] = beta
        TC_A['track'] = track
        field = 0.0
        bf.blockfind_TC_AT(temp, field, afzero, V, TC_A) 

        TC_A['trm_a'][var_c][track] = TC_A['totalm'] 
        TC_A['temp_a'][var_c][track] = temp
        TC_A['blockper_t'][t_b] = TC_A['blockper']
        TC_A['boltz_t'][t_b] = sum(TC_A['boltz'])
        TRM_ac_hys_TC_A.append(TC_A['totalm'])

        if (temp <= 750.):
            tempstep1 = tempstep*10.
        elif (temp <= 840.) and (temp > 810.):
            tempstep1 = tempstep/2.
        else:
            tempstep1 = tempstep
        temp = temp - tempstep1
        track += 1
        t_b +=1
    
   
    temp = temp + 0.1
    beta= (1-(temp-273)/578.0)**0.43
    TC_A['beta'] = beta

    bf.blockfind_TC_AT(temp, field, afzero, V, TC_A)
    V['end_mag'] = 1.0
    TC_A['tm'] = 60.0
    bf.blockfind_TC_AT(temp, 0.0, afzero, V, TC_A)
    V['end_mag']= 0.0

    TC_A['max_tcrm'][var_c] = TC_A['totalm']

    counttime_TC_A = TC_A['counttime'] 
    TC_A['len_a_trm'][var_c] = track 
    counttimetrm = counttime_TC_A

    TC_T = copy.deepcopy(TC_A)
    
    
    rate = 0
    TC_A['rate'] = rate
    tm = 60
    TC_A['tm'] = tm

    TC_A['temp'] = temp
   
    
    
    beta = (1 - (temp - 273)/578.0)**0.43
    TC_A['beta'] = beta
    fieldzero = 0.0

    bf.blockfind_TC_AT(temp, fieldzero, afzero, V, TC_A) 
    counttime_TC_A = counttime_TC_A - 1
    TC_A['counttime'] = counttime_TC_A
    
    TC_A['t_b'] = t_b
    #calc AF demag of TCRM 

    TC_A['afmag'][var_c, 0] = TC_A['totalm']

    for i in range(cntfields): 
        for kk in range(1):
            afstore = af_step[i]
            TC_A['afstore'] = afstore
            bf.blockfind_TC_AT(temp, fieldzero, afone, V, TC_A) 

            afcount_TC_A[TC_A['counttime']] = afstore

            TC_A['afmag'][var_c, i] = TC_A['aftotalm']

    j = var_c

    cntfieldaf_TC_A = 0

    afstore = 0.0
    TC_A['afstore'] = afstore

    #calc SIRM 

    blockg = np.ones(num_hyss)
    boltz = np.ones(num_hyss)
    blocktemp = np.ones(num_hyss) 
    TC_A['blocktemp'] = blocktemp
    TC_A['boltz'] = boltz
    TC_A['blockg'] = blockg
    TC_A['blockper'] = 1.

    fieldzero = 0.0
    TC_A['sir'] = 0

    bf.blockfind_TC_AT(temp, fieldzero, afone, V, TC_A)


    TC_A['sirm'][var_c,0] = TC_A['sir'] 
    
    sirmtotalmplot = np.zeros((25))

    for i in range(cntfields): 
        for kk in range(1):
            afstore = af_step[i]
            TC_A['afstore'] = afstore 

            bf.blockfind_TC_AT(temp, fieldzero, afone, V, TC_A)

            TC_A['sirm'][var_c,i] = TC_A['sir'] 



    counttime_TC_A = TC_A['counttime']
    counttime_TC_A = counttime_TC_A +1 
    TC_A['counttime'] = counttime_TC_A
    negs = 0.0 

    negsirm_TC_A[var_c] = -negs

    TC_A['aconst'] = aconst

    TC_T['sirm'] = TC_A['sirm']

    pl.plot_CRM_acquired_time(V, TC_A, var_c) #plot CRM acquired at that variable value
    pl.plot_TRM_acquired(V, TC_A, var_c) #plot TRM acquired at that variable value
    pl.plot_sirm(TC_A, TC_A, V, var_c) #plot SIRM demag for TRM and CRM at this variable value
    pl.plot_rem_demag(V, TC_A, TC_A, var_c)
    


    affield = 0
    affmax = 0.0
    af_step_max = 0.0
    flatsub=0
    flat=0


    
    demag_field = TC_T['demag_field']

    

    td = 0
    fieldzero = 0.0
    ttest_step = 20 
    #Thellier temp steps 
    Ttest_arr = np.array([320., 400., 500., 600., 700., 750., 775., 780., 785., 790., 795., 800.,805., 807., 810., 812., 815., 818., 820., 821., 823., 824., 825., 826., 827., 828., 830., 831., 833., 835., 837., 840., 849., 860.])

    ptrm_t = np.array([0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.])
    tail_t = np.array([0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.])   

    Ttest = Ttest_arr[td]  
    tempmax = 577+273
    ac = 1. 

    p = 0 # track ptrm temps
    t = 0
    k = 0   
    temp = tempmin + tempstep*10.
    
    while (Ttest < tempmax):
        
        while (temp <= Ttest): #heat up to Ttest in zero field

            V['heating'] =1.
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TC_T['aconst'] = aconst
            beta= (1-(temp-273)/578.0)**0.43
            TC_T['beta'] = beta
            field = 0.0
            bf.blockfind_TC_T(temp, field , afzero, V, TC_T) #mag remain at temp step 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1

        temp = temp - tempstep1
        while (temp > tempmin): #cool down in zero field from temerature step and measure magnetisation

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TC_T['aconst'] = aconst

            beta= (1-(temp-273)/578.0)**0.43
            TC_T['beta'] = beta
            field = 0.0
            V['heating'] = 0.
            bf.blockfind_TC_T(temp, field, afzero, V, TC_T) #mag remain at temp step 
            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1        

        temp = temp + tempstep1

		
        temp_r = 300.1
		
        beta= (1-(temp_r-273)/578.0)**0.43

        TC_T['beta'] = beta
        bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T)
        V['end_mag'] = 1.0
        bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T)
        V['end_mag'] = 0.0
        
        TC_T['NRM_r'][var_c, td] = TC_T['totalm'] #NRM remaining magnetisation after this

        TC_T['Ttest_list'][var_c, td] = Ttest
		
        TC_T['temp_PI'][var_c, k] = Ttest 
        TC_T['mag_PI'][var_c, k] = TC_T['totalm']
        k+=1		

		
        if (ptrm_t[td] == 1.): #if doing ptrm check on this step
            TC_T['temp_heat'][var_c, td] = Ttest 
            TC_T['temp_check'][var_c, td] = Ttest_arr[td-2]
            while (temp <= Ttest_arr[td-2]): 
                TC_T['reheat'] = 'yes'
                V['heating'] =1.

                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                TC_T['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                TC_T['beta'] = beta
                field = TC_T['demag_field']
                bf.blockfind_TC_T(temp, field, afzero, V, TC_T) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                TC_T['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                TC_T['beta'] = beta
                field = TC_T['demag_field']
                V['heating'] = 0.
                bf.blockfind_TC_T(temp, field, afzero, V, TC_T) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1    

            temp = temp + tempstep1

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TC_T['aconst'] = aconst
            beta= (1.-(temp_r-273.)/578.0)**0.43
            TC_T['beta'] = beta
			
            bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T)

            V['end_mag'] = 1.0

            field = 0.0
            bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T) 

            V['end_mag'] = 0.0
            ptrm = TC_T['totalm']
			
            TC_T['NRM_check'][var_c,td] = TC_T['NRM_r'][var_c, td]
            TC_T['pTRM_M3'][var_c, td] = ptrm

            TC_T['pTRM_check'][var_c, td] = ptrm - TC_T['NRM_r'][var_c, td] 
			
            TC_T['temp_PI'][var_c, k] = Ttest_arr[td-2] + 0.2
            TC_T['mag_PI'][var_c, k] = TC_T['totalm']
            k+=1
			
			
            p +=1		

		
        while (temp <= Ttest): 

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TC_T['aconst'] = aconst
            beta= (1-(temp-273)/578.0)**0.43
            TC_T['beta'] = beta
            field = TC_A['demag_field']
            V['heating'] = 1.
            bf.blockfind_TC_T(temp, field, afzero, V, TC_T) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1
        while (temp > tempmin):

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TC_T['aconst'] = aconst

            beta= (1-(temp-273)/578.0)**0.43
 
            TC_T['beta'] = beta
            field = TC_A['demag_field']
            V['heating'] = 0.
            bf.blockfind_TC_T(temp, field, afzero, V, TC_T) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1       

        temp = temp + tempstep1
		
        beta= (1-(temp_r-273)/578.0)**0.43
        TC_T['beta'] = beta
        bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T)
        field = 0.0
        V['end_mag'] = 1.0
        bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T)
        V['end_mag'] = 0.0

        TC_T['temp_PI'][var_c, k] = Ttest + 0.1
        TC_T['mag_PI'][var_c, k] = TC_T['totalm']
        k+=1		
		
        TC_T['M_2'][var_c, td] = TC_T['totalm']
        TC_T['pTRM'][var_c, td] = TC_T['M_2'][var_c, td] - TC_T['NRM_r'][var_c, td]

		
		
        if (tail_t[td] == 1.):
            while (temp <= Ttest): 
                field = 0.0
                TC_T['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TC_T['beta'] = (1-(temp-273)/578.0)**0.43

                V['heating'] = 1.
                bf.blockfind_TC_T(temp, field, afzero, V, TC_T) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                TC_T['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TC_T['beta'] = (1-(temp-273)/578.0)**0.43
                V['heating'] = 0.
                bf.blockfind_TC_T(temp, field, afzero, V, TC_T) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1         
        
            temp = temp + tempstep1 

            temp_r = 300.1
            TC_T['beta'] = (1-(temp_r-273)/578.0)**0.43
            bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T)
            V['end_mag'] = 1.0
            field = 0.0

            bf.blockfind_TC_T(temp_r, field, afzero, V, TC_T) 
  
            TC_T['mag_tail'][var_c, td] = TC_T['totalm'] 

            V['end_mag'] = 0.0
            TC_T['temp_tail'][var_c, td] = Ttest

			
            TC_T['temp_PI'][var_c, k] = Ttest + 0.3
            TC_T['mag_PI'][var_c, k] = TC_T['totalm']
            k+=1
            t+=1		
		
		
        td += 1
        Ttest = Ttest_arr[td]
    field = V['field']
    counttime_TC_T = TC_T['counttime'] 
    TC_T['len_a_Ttrm_demag'][var_c] = td 
    counttimetrm_TC_T = counttime_TC_T

    j = var_c 

    afstore_TC_T = 0.0
    TC_T['afstore'] = afstore_TC_T

    counttime_TC_T = TC_T['counttime']
    counttime_TC_T = counttime_TC_T +1 
    TC_T['counttime'] = counttime_TC_T
    negs = 0.0

    pl.highT_NRM_pTRM(TC_T, V, var_c)
    V['aconst'] = aconst
    pl.TCRM_thermal_demag(TC_T, V, var_c)

    ac = 1.
    f = open('{}\{}_TCRM_arai.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" 'NRM_r' + "\t" + 'pTRM \n')
    for i in range(int(TC_T['len_a_Ttrm_demag'][var_c])):
        f.write(str(TC_T['Ttest_list'][var_c, i]) + "\t" + str(TC_T['NRM_r'][var_c][i]) + "\t" + str(TC_T['pTRM'][var_c][i]) + "\n")
    f.close()
	

    f= open('{}\{}_AF_demag.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('field step' + "\t" + 'TRM' + "\t" 'CRM' + "\t" + 'SIRM \n')
    for i in range(int(TC_A['cntfield'])):
        f.write(str(TC_A['afmag'][var_c][i]) + "\t" + str(TC_A['afmag'][var_c][i]) + "\t" + str(TC_A['sirm'][var_c][i]) + "\n")
    f.close()
    
	
    f = open('{}\{}_TCRM_PI.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'mag' + '\n')
    for i in range(k):
        f.write(str(TC_T['temp_PI'][var_c, i]) + "\t" + str(TC_T['mag_PI'][var_c, i]) + "\n")
    f.close()	
	
    f= open('{}\{}_{}_prop.txt'.format(dire,variable_change[var_c], var_c), 'w')
    f.write('mean x' + "\t" + str(mu_x) + '\n')
    f.write('max x' + "\t" + str(xmax) + '\n')
    f.write('variance x' + "\t" + str(variance_x) + '\n')
    f.write('stdev x' + "\t" + str(stdev_x) + '\n')
    f.write('stdev y' + "\t" + str(stdev_y) + '\n')
    f.write('mean int field' + "\t" + str(V['mean_int_field'][var_c]) + '\n')    
    f.write('mean y' + "\t" + str(mu_y) + '\n')
    f.write('max y' + "\t" + str(ymax) + '\n')
    f.write('variance y' + "\t" + str(variance_y) + '\n')
    f.write('num hyss in remamance zone' + "\t" + str(V['num_hyss']) + '\n')
    f.write('growth rate' + "\t" + str(g) + '\n')
    f.write('applied field' + "\t" + str(V['field']) + '\n')

    f.write('variable adjusting' + "\t" + str(V['variable_c']) + '\n')
    f.write('variable adjusting value' + "\t" + str(V['variable_change'][var_c]) + '\n')
    f.close()
   
    var_c = var_c +1 

	
f= open('{}\max_mag.txt'.format(dire), 'w')
f.write('variable value' + "\t" + 'max TCRM' + "\t" + ' max SIRM \n')
for var_c in range(int(V['len_var'])):
    f.write(str(V['variable_change'][var_c]) + "\t" + str(TC_A['max_tcrm'][var_c]) + "\t" + str(TC_A['sirm'][var_c][0]) + "\n")

f.write(str("--- %s seconds ---" % (time.time() - start_time)))
f.close()

pl.TCRM_var(TC_A, V)
pl.SIRM_var_HT(TC_A, V)



#import functions
import general as ge
import plots as pl
import BF_arai_AF_HT as bf
import copy 
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
import os as os
from math import pi, log, log10, ceil
import time

start = time.time()

#constant variables
tempt=300. #room tmep 
ms0 = 491880.5 #Ms for magnetite
mu0 = 4.*pi*1e-7 
kb = 1.3806503e-23
tau = 1e-9
roottwohffield = 2.**(0.5)  

eul = 1.78107 #exp(eulers const)

fieldzero = 0

#declare dictionaries
V = {}
ST = {}
SC = {}
I = {}
TT = {}
CT = {} 

V['name'] = 'sample_name' # input name of sample
V['variable_c'] = 'variable_c_4' # variable changing - folder name


V['variable_change'] = np.array((0.001, 0.01)) #interaction changing in this case
V['max_y_arr'] = np.array((0.007, 0.038))


len_var = len(V['variable_change'])
V['len_var'] = len_var
var_c =0 


field = 50.0E-6/mu0 #field strength 
V['field'] = field

#number of hysterons
num_hyss_pre = 100000
V['num_hyss'] = num_hyss_pre

#temp parameters
tempmax=577.+273. # one degree less than Tc
tempmin=300.
V['tempmin'] = tempmin
V['tempmax'] = tempmax
tempstep=1.
V['tempstep'] = tempstep

#time constant in hours - rate of cooling
ac = 1. 

#CRM growth rate
g = 1E-13

#initiate errors
ST['err_t'] = 0.0 
ST['err_s'] = 0.0 
SC['err_c'] = 0.0 
SC['err_s'] = 0.0 
SC['err_t'] = 0.0 


variable_change = V['variable_change']

#make new folder for variable
current_directory = os.getcwd()
final_directory = os.path.join(current_directory, V['variable_c'])
if not os.path.exists(final_directory):
    os.makedirs(final_directory)
    
V['dir'] = final_directory

#arrays for tracking and plotting 
ge.make_arrays_th_af(ST, SC, V)

var_c = 0
#loop over gCRM and TRM acquisition for each value of variables 
for var_c in range(len(V['variable_change'])):
    
    V['end_mag'] = 0.0

    cntfield = ST['cntfield']
    demag_f = 50E-6
    demag_field = demag_f/mu0
    ST['demag_field'] = demag_field
    SC['demag_field'] = demag_field

    field = (50E-6)/mu0
    V['field'] = (50E-6)/mu0    
    
    V['num_hyss'] = num_hyss_pre
    #variable defines by variable_c
    
    #FILL PREISACH DISTRIBUTION 
    ymax = V['max_y_arr'][var_c]
    stdev_y = V['variable_change'][var_c]
    variance_y = ((stdev_y)**2)
    stdev_x = 5E-3
    variance_x = (stdev_x)**2
    mu_x = 0.02   
    xmax = 0.038 
    cntfield = ST['cntfield']

    x = np.linspace(0,xmax,250)
    y = np.linspace(-ymax,ymax,250)
    X, Y = np.meshgrid(x,y)
    
    pos = np.empty(X.shape + (2,))
    pos[:, :, 0] = X; pos[:, :, 1] = Y
    rv = multivariate_normal([mu_x, mu_y], [[variance_x, 0], [0, variance_y]]) #make guassian preisach distribution
    z = rv.pdf(pos)
    

    ST['x'] = X
    ST['y'] = Y
    ST['z'] = z
    SC['x'] = X
    SC['y'] = Y
    SC['z'] = z
    I['x'] = X
    I['y'] = Y
    I['z'] = z
    ge.norm_z(ST, SC, I, var_c) 
    pl.plot_z(V, ST, SC, I, var_c) #plot preisach distribuition
    ms=ms0*(1-(tempt-273)/578.0)**0.43 #functon to determine ms at any temperature
    tm = 0.2
    I['ms'] = ms
    I['tm'] = tm
    hys, num_pop = ge.pop_hys(num_hyss_pre, V, I) #populate hysterons
    I['hys'] = hys
    I,V = ge.blocked_hys(I,V)  #number hysterons initially blocked for normlaisation of interactions 
    mean_int = np.sum((abs(hys[:,1]))*hys[:,3])
    mean_int_1 = mean_int/np.sum(hys[:,3])
    mean_int_2 = mean_int_1*mu0
    V['mean_int_field'][var_c] = mean_int_2
    num_hyss = V['num_hyss'] 

    #TRM model

    #define variables
    afone = 1
    afzero = 0
    ST['counttime'] = 0
    ST['blockper'] = 0.00000001
 
    ST['hcstore'] = np.zeros(num_hyss)
    ST['histore'] = np.zeros(num_hyss)

    ac = 1. #cooling time in hours
    #main TRM model

    ST['countiold'] = num_hyss 
    af_step = ST['AF_steps']
    ST['blocktemp'] = np.zeros(num_hyss) #hysterons temp location in preisach space
    ST['boltz'] = np.zeros(num_hyss) #percentage alignment of moment with field 
    ST['blockg'] = np.zeros(num_hyss) #hysterons location in preisach space
    ST['totalm'] = 0
    ST['sir'] = 0
    ST['aftotalm'] = 0


    temp=300. #room temp 
    ms=ms0*(1.-(tempt-273.)/578.0)**0.43 
    ST['ms'] = ms
    tm = 0.2 #FORC measuring time
    ST['tm'] = tm
    sense = np.ones(num_hyss) 
    ST['sense'] = sense
    temp = tempmax
    rate = 1 
    ST['rate'] = rate
    ST['totalblocktwo'] = 0
    ST['totalblock'] = 0

    field = V['field']

    afswitch = afzero

    ST['hys'] = copy.deepcopy(I['hys']) #copy main dictionary for TRM acquisitoin 

    hys = ST['hys']
    tm = 0.
    aftotalm = 0
    ST['aftotalm'] = aftotalm
    ST['tm'] = tm 
    track = 0

    V['heating'] = 0.0

    ST['afstore'] = 0.0

    tempstep = 1.
    while (temp > tempmin): #cooling during TRM acquisition

        ST['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) #calculate coling constant at each temperature
        ST['beta'] = (1-(temp-273)/578.0)**0.43 #beta for relation of Ms with temperature at each step 
        ST['track'] = track
        bf.blockfind_ST(temp, field, afzero, V, ST) #calculate magnetisation at each temperature
        ST['trm_a'][var_c][track] = ST['totalm'] 
        ST['temp_a'][var_c][track] = temp


        if (temp <= 750.):
            tempstep1 = tempstep*10.
        elif (temp <= 840.) and (temp > 810.):
            tempstep1 = tempstep/2.
        else:
            tempstep1 = tempstep

        temp = temp - tempstep1
        track += 1

    ST['len_a_trm'][var_c] = track 
 
    temp = temp + 0.1
    

    ST['beta'] = (1. - (temp - 273.)/578.0)**0.43 
    bf.blockfind_ST(temp, field, afzero, V, ST) #calculate magnetisation at end temp temperature
    tm = 60.0
    V['end_mag'] = 1.0 
    field = 0.0
    bf.blockfind_ST(temp, field, afzero, V, ST) #calculate magnetisation at end temperature once applied field removed 
    
    TT = copy.deepcopy(ST) #copy dictionary containing TRM magnetisation infomation after acquisition for use in Thellier procedure 
    #AF demag stage for TRM 
    V['end_mag'] = 0.0
    field = V['field']
    ST['rate'] = 0
    ST['tm'] = 60.
    ST['beta'] = (1. - (temp - 273.)/578.0)**0.43

    ST['max_trm'][var_c] = ST['totalm'] 
    ST['counttime'] = ST['counttime'] -1 
    #calc AF demag of TRM 
    ST['afmag'][var_c, 0] = ST['totalm']
    for i in range(cntfield): 
        ST['afstore'] = af_step[i]
        bf.blockfind_ST(temp, fieldzero, afone, V, ST) #calculate magnetisation at each AF step 

        ST['afmag'][var_c, i] = ST['aftotalm']

    j = var_c

    ST['afstore'] = 0.0

    #calc SIRM
    #saturation sample so all blocked with the applied saturating field 
    ST['blocktemp'] = np.ones(num_hyss) 
    ST['boltz'] = np.ones(num_hyss) 
    ST['blockg'] = np.ones(num_hyss) 
    ST['blockper'] = 1.

    ST['sir'] = 0

    bf.blockfind_ST(temp, fieldzero, afone, V, ST) #calculate SIRM magnetisation 

    cntfields = cntfield

    ST['sirm'][var_c,0] = ST['sir'] 
  
    for i in range(cntfield): 
        for kk in range(1):
            afstore_T = af_step[i]
            ST['afstore'] = afstore_T

            bf.blockfind_ST(temp, fieldzero, afone, V, ST)

            ST['sirm'][var_c,i] = ST['sir']

   
    pl.plot_TRM_acquired(V, ST, var_c) 
    pl.TRM_AF_demag(V, ST, var_c)
    
    negs = 0.0 
    V['aconst'] = ST['aconst']

    #CRM model
    SC['blockper'] = 0.0

    SC['hcstore'] = np.zeros(num_hyss) #track hc for testing 
    SC['histore'] = np.zeros(num_hyss)    
    SC['count_b'] =0


    #set variables 
    final_R = np.zeros(num_hyss) #array for final radius of each hysteron 

    SC['tm'] = 0.2 #tm during FORC measurement

    SC['countiold'] = num_hyss 

    af_step = SC['AF_steps']
    SC['blocktemp'] = np.zeros(num_hyss) #set all hysterons as SP 
    SC['boltz'] = np.zeros(num_hyss)
    SC['blockg'] = np.zeros(num_hyss)
    SC['totalm'] = 0
    SC['sir'] = 0
    SC['aftotalm'] = 0

    temp= tempmin + 0.1 #set temperature as room temperature 

    SC['tm'] = 0.2
    SC['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
    SC['beta'] = (1-((temp-273)/578.0))**0.43
    SC['ms'] = ms0*SC['beta']
    SC['temp'] = temp

    SC['sense'] = np.ones(num_hyss)

    rate = 1 
    t =0 
    V['end_mag'] = 0.0
    SC['rate'] = rate
    SC['totalblocktwo'] = 0
    SC['totalblock'] = 0


    afswitch = afzero

    SC['hys'] = copy.deepcopy(I['hys'])
    hys = SC['hys']

    Ro = 1E-09#nucleation radius 
    prop = np.zeros((num_hyss,12))
    prop[:,9] = ms*mu0*hys[:,9] #eo for constant de/dv 
    prop[:,0] = hys[:,10] #Vf
    prop[:,1] = (3*prop[:,0]/(4*pi))**(1./3.) #Rf 
    final_R = prop[:,1]
    prop[:,2] = (prop[:,1] - Ro)/g #growth time in seconds
    maxt = np.max(prop[:,2]) #max growth time 
    prop[:,3] = (maxt- prop[:,2])#nucleation times 

    SC['prop'] = prop
    SC['totalvol'] = sum(prop[:,0])

    #CRM acquisition

    t = 0
    tstep = maxt/3000 #time step size
    SC['tstep'] = tstep

    tot_time_steps = (np.max(prop[:,2])+0.5*tstep)/tstep
    tot_time_steps = ceil(tot_time_steps)

    tm = 0

    SC['aftotalm'] = 0
    SC['tm'] = tm 
    x=0 #loop over time steps
    field = V['field']
    SC['afstore'] = 0.0
    while (t <= (np.max(prop[:,2]) + 0.5*tstep)): #loop over each time step 

        prop = ge.find_tm(prop, num_hyss, t, g, Ro, eul, tau, tstep) #calcualte the effective time at each time step for each hysteron 

        SC['track'] = x
        SC['prop'] = prop
        bf.blockfind_SC(t, field, afzero, V, SC) #calculate magnetisation at each time step for each hysteron 

        SC['crm_a'][var_c,x] = SC['totalm'] 


        SC['time_a'][var_c,x] = t
        SC['vol_a'][var_c,x] = np.mean(prop[:,5])
        SC['rad_a'][var_c,x] = np.mean(prop[:,4])

        x+=1

        if (t <= (0.4*np.max(prop[:,2]) + 0.5*tstep)): 
            t+= 10*tstep
        else:
            t+= tstep 
    t = t - tstep
    
   
    V['end_mag'] = 1.0
    bf.blockfind_SC(t, fieldzero, afzero, V, SC) #calculate magnetisation at the end of CRM acquisition
    V['end_mag'] = 0.0
    SC['max_crm'][var_c] = SC['totalm'] 
   
    CT = copy.deepcopy(SC) #copy CRM data for Thelllier 


    SC['len_a_crm'][var_c] = x
    SC['rate'] = 0
    SC['tm'] = 60
    SC['beta'] = (1 - (temp - 273)/578.0)**0.43
    SC['ms'] = ms0*SC['beta']


    #calc AF demag of CRM

    SC['afmag'][var_c, 0] = SC['totalm'] 

    for i in range(cntfield):

        SC['afstore'] = af_step[i]
        bf.blockfind_SC(t, fieldzero, afone, V, SC) 

        SC['afmag'][var_c, i] = SC['aftotalm'] 

    j = var_c

    SC['afstore'] = 0

    #calc SIRM

    prop = SC['prop']

    tm = 60.0

    SC['prop'] = prop

    SC['blocktemp'] = np.ones(num_hyss)
    SC['boltz'] = np.ones(num_hyss)
    SC['blockg'] = np.ones(num_hyss)
    SC['blockper'] = 1.

    SC['sir'] = 0

    bf.blockfind_SC(t, fieldzero, afone, V, SC)


    cntfields = cntfield 

    SC['sirm'][var_c,0] = SC['sir'] 

    for i in range(cntfield): 
        for kk in range(1):
            afstore_C = af_step[i]
            SC['afstore'] = afstore_C
            bf.blockfind_SC(t, fieldzero, afone, V, SC)
            SC['sirm'][var_c,i] = SC['sir'] 





    #make plots for each variable
    pl.plot_CRM_acquired_time(V, SC, var_c) #plot CRM acquired at that variable value
    pl.plot_sirm(SC, ST, V, var_c) #plot SIRM demag for TRM and CRM at this variable value
    pl.plot_rem_demag(V, ST, SC, var_c)
    pl.CRM_AF_demag(V, SC, var_c)


    temp=300.

    ms=ms0*(1.-(tempt-273.)/578.0)**0.43 
 
    afswitch = afzero

    V['end_mag'] = 0.0
    
    #this is final magnetisation
    #end of TRM acquision
    #thermal demag 
    td = 0
    #set Thellier steps and which havea pTRM check or tail check
    Ttest_arr = np.array([320., 400., 500., 600., 700., 750., 775., 780., 785., 790., 795., 800.,805., 807., 810., 812., 815., 818., 820., 823., 825., 828., 830., 833., 835., 837., 840., 860.])

    ptrm_t = np.array([0., 0., 0., 0., 1., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 0., 1., 0., 0.])
    tail_t = np.array([0., 0., 0., 0., 0., 1., 0., 1., 0., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0., 0., 1., 0.])  
   


    Ttest = Ttest_arr[td] 

    temp = tempmin + tempstep*10
    p = 0 # track ptrm temps
    t = 0
    k = 0
    ac = 1. #1hr cooling time in Lab measurements
    while (Ttest < tempmax):
        
        while (temp <= Ttest): #heat up to Ttest in zero field 
            
            V['heating'] = 1.
            field = 0.0
            TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TT['beta'] = (1-(temp-273)/578.0)**0.43
 
            bf.blockfind_TT(temp, field, afzero, V, TT) #mag remain at temp step 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1
      
        while (temp > tempmin): #cool down in zero field from temerature step and measure magnetisation

            V['heating'] = 0.0
            TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            TT['beta'] = (1-(temp-273)/578.0)**0.43
            bf.blockfind_TT(temp, field, afzero, V, TT) #mag remain at temp step 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1       
        
        temp = temp + tempstep1 

        
        temp_r = 300.1
        TT['beta'] = (1-(temp_r-273)/578.0)**0.43
        bf.blockfind_TT(temp_r, field, afzero, V, TT)
        V['end_mag'] = 1.0
        field = 0.0
        #TRM removed during heating and cooling in zero field
        bf.blockfind_TT(temp_r, field, afzero, V, TT) 
       
        TT['NRM_r'][var_c, td] = TT['totalm'] 
        TT['temp_PI'][var_c, k] = Ttest 
        TT['mag_PI'][var_c, k] = TT['totalm']
        k+=1

        V['end_mag'] = 0.0
        TT['Ttest_list'][var_c, td] = Ttest

        
        if (ptrm_t[td] == 1.): #pTRM check step 
            TT['temp_heat'][var_c, td] = Ttest 
            TT['temp_check'][var_c, td] = Ttest_arr[td-2]
            while (temp <= Ttest_arr[td-2]): 
                TT['reheat'] = 'yes'
                print('temp: during heat in zero field before pTRM acquired', temp)
                V['heating'] = 1.
                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                TT['beta'] = beta
                field = TT['demag_field']
                bf.blockfind_TT(temp, field, afzero, V, TT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

			
            while (temp > tempmin): #cool down in field from temerature step and measure magnetisation for pTRM check 

                V['heating'] = 0.0
                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                TT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                TT['beta'] = beta
                field = TT['demag_field']
                bf.blockfind_TT(temp, field, afzero, V, TT) #mag remain at temp step 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1 

            temp = temp + tempstep1


            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TT['aconst'] = aconst
            beta= (1.-(temp_r-273.)/578.0)**0.43
            TT['beta'] = beta
			
            bf.blockfind_TT(temp_r, field, afzero, V, TT)
			

            V['end_mag'] = 1.0

            field = 0.0
            bf.blockfind_TT(temp_r, field, afzero, V, TT) #mag remain at temp step 

            V['end_mag'] = 0.0
            ptrm = TT['totalm']
			
            TT['NRM_check'][var_c,td] = TT['NRM_r'][var_c, td]
            TT['pTRM_M3'][var_c, td] = ptrm

            TT['pTRM_check'][var_c, td] = ptrm - TT['NRM_r'][var_c, td] 
			
            TT['temp_PI'][var_c, k] = Ttest_arr[td-2] + 0.2
            TT['mag_PI'][var_c, k] = TT['totalm']
            k+=1
			
			
            p +=1
			
        while (temp <= Ttest): #heat up to Ttest and cool in field for pTRM step 
            TT['reheat'] = 'yes'
            V['heating'] = 1.

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            TT['beta'] = beta
            field = TT['demag_field']
            bf.blockfind_TT(temp, field, afzero, V, TT)  

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1

        
        while (temp > tempmin): #cool down in field from temerature step and measure magnetisation

            V['heating'] = 0.
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            TT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            TT['beta'] = beta
            field = TT['demag_field']
            bf.blockfind_TT(temp, field, afzero, V, TT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1   

        temp = temp + tempstep1


        aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
        TT['aconst'] = aconst
        beta= (1.-(temp_r-273.)/578.0)**0.43
        TT['beta'] = beta
		
        bf.blockfind_TT(temp_r, field, afzero, V, TT)
		
        TT['Ttest_list'][var_c, td] = Ttest
        V['end_mag'] = 1.0

        field = 0.0
        bf.blockfind_TT(temp_r, field, afzero, V, TT) 

        V['end_mag'] = 0.0
        TT['M_2'][var_c, td] = TT['totalm']

        TT['pTRM'][var_c, td] = TT['M_2'][var_c, td] - TT['NRM_r'][var_c, td] 

        TT['temp_PI'][var_c, k] = Ttest + 0.1
        TT['mag_PI'][var_c, k] = TT['totalm']
        k+=1

        
        if (tail_t[td] == 1.): #pTRM tail check, heat and cool in zero field 
            while (temp <= Ttest): 
                field = 0.0
                V['heating'] = 1.
                TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TT['beta'] = (1-(temp-273)/578.0)**0.43

                bf.blockfind_TT(temp, field, afzero, V, TT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                V['heating'] = 0.
                TT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                TT['beta'] = (1-(temp-273)/578.0)**0.43
                bf.blockfind_TT(temp, field, afzero, V, TT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1       
        
            temp = temp + tempstep1 

        
            temp_r = 300.1
            TT['beta'] = (1-(temp_r-273)/578.0)**0.43
            bf.blockfind_TT(temp_r, field, afzero, V, TT)
            V['end_mag'] = 1.0
            field = 0.0

            bf.blockfind_TT(temp_r, field, afzero, V, TT) 
      
            TT['mag_tail'][var_c, td] = TT['totalm'] 

            V['end_mag'] = 0.0
            TT['temp_tail'][var_c, td] = Ttest			
			
            TT['temp_PI'][var_c, k] = Ttest + 0.3
            TT['mag_PI'][var_c, k] = TT['totalm']
            k+=1
            t+=1

        td += 1
        Ttest = Ttest_arr[td]

        
        
   

    V['end_mag'] = 0.0    

    TT['len_a_trm_demag'][var_c] = td 
    field = V['field']

    j = var_c 
    TT['afstore'] = 0.0



    pl.TRM_thermal_demag(TT, ST, V,var_c) #plot TRM arai plot

    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']    
    f = open('{}\{}_TRM_arai.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_f' + "\t" 'NRM_r' + "\t" + 'pTRM' + "\t" + 'm_2' + '\n')
    for i in range(int(TT['len_a_trm_demag'][var_c])):
        f.write(str(TT['Ttest_list'][var_c, i]) + "\t" + str(TT['Ttest_list'][var_c, i]) + "\t" + str(TT['NRM_r'][var_c][i]) + "\t" + str(TT['pTRM'][var_c][i]) + "\t" + str(TT['M_2'][var_c][i]) + "\n")
    f.close()
	
    f = open('{}\{}_TRM_PI.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'mag' + '\n')
    for i in range(k):
        f.write(str(TT['temp_PI'][var_c, i]) + "\t" + str(TT['mag_PI'][var_c, i]) + "\n")
    f.close()    
    
    
    
    
    TT['hys'] = copy.deepcopy(I['hys'])
    #CRM model with thermal demag

    afone = 1
    afzero = 0

    demag_field = CT['demag_field']

    field = V['field']
    temp = tempmin + 0.1 
    ms=ms0*(1-(tempt-273)/578.0)**0.43 
    afswitch = afzero


    V['end_mag'] = 0.0        
    td = 0     
    fieldzero = 0.0


    Ttest = Ttest_arr[td] 

    ac = 1.

    temp = tempmin + tempstep*10.
    p = 0
    t = 0
    k = 0
    #repeat Thellier process for CRMs using same Thellier steps
    while (Ttest < tempmax):
        CT['Ttest_list'][j,td] = Ttest

        while (temp <= Ttest): 

            V['heating'] = 1.
            CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            CT['beta'] = (1-(temp-273)/578.0)**0.43
            field = 0.0
            bf.blockfind_CT(temp, field, afzero, V, CT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1
        
        while (temp > tempmin):

            V['heating'] = 0.0
            CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
            CT['beta'] = (1-(temp-273)/578.0)**0.43
            field = 0.0
            bf.blockfind_CT(temp, field, afzero, V, CT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1       

        
        temp = temp + tempstep1

        CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
        CT['beta'] = (1-(temp_r-273)/578.0)**0.43
        bf.blockfind_CT(temp_r, 0.0, afzero, V, CT)
		
		
        field = 0.0
        
        V['end_mag'] = 1.0
        bf.blockfind_CT(temp_r, 0.0, afzero, V, CT)
        V['end_mag'] = 0.0
        CT['temp_PI'][var_c, k] = Ttest
        CT['mag_PI'][var_c, k] = CT['totalm']
        k+=1
    
        CT['NRM_r'][var_c, td] = CT['totalm'] 


        if (ptrm_t[td] == 1.): 
            CT['temp_heat'][var_c, td] = Ttest 
            CT['temp_check'][var_c, td] = Ttest_arr[td-2]
            while (temp <= Ttest_arr[td-2]):
                CT['reheat'] = 'yes'
                V['heating'] = 1.

                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                CT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                CT['beta'] = beta
                field = CT['demag_field']
                bf.blockfind_CT(temp, field, afzero, V, CT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

			
            while (temp > tempmin): 

                V['heating'] = 0.
                aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
                CT['aconst'] = aconst
                beta= (1.-(temp-273.)/578.0)**0.43
                CT['beta'] = beta
                field = CT['demag_field']
                bf.blockfind_CT(temp, field, afzero, V, CT)

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1  

            temp = temp + tempstep1

            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            CT['aconst'] = aconst
            beta= (1.-(temp_r-273.)/578.0)**0.43
            CT['beta'] = beta
			
            bf.blockfind_CT(temp_r, field, afzero, V, CT)
			

            V['end_mag'] = 1.0

            field = 0.0
            bf.blockfind_CT(temp_r, field, afzero, V, CT)  
 
            V['end_mag'] = 0.0
            ptrm = CT['totalm']
			
            CT['NRM_check'][var_c,td] = CT['NRM_r'][var_c, td]
            CT['pTRM_M3'][var_c, td] = ptrm

            CT['pTRM_check'][var_c, td] = ptrm - CT['NRM_r'][var_c, td] 
			
            CT['temp_PI'][var_c, k] = Ttest_arr[td-2] + 0.2
            CT['mag_PI'][var_c, k] = CT['totalm']
            k+=1
			
			
            p +=1        
		
        while (temp <= Ttest): 

            V['heating'] = 1.
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            CT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            CT['beta'] = beta
            field = CT['demag_field']
            bf.blockfind_CT(temp, field, afzero, V, CT) 


            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp + tempstep1
        temp = temp - tempstep1

        
        while (temp > tempmin): 

            V['heating'] = 0.
            aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
            CT['aconst'] = aconst
            beta= (1.-(temp-273.)/578.0)**0.43
            CT['beta'] = beta
            field = CT['demag_field']

            bf.blockfind_CT(temp, field, afzero, V, CT) 

            if (temp <= 750.):
                tempstep1 = tempstep*10.
            elif (temp <= 840.) and (temp > 810.):
                tempstep1 = tempstep/2.
            else:
                tempstep1 = tempstep
            temp = temp - tempstep1    


        temp = temp + tempstep1
        
        aconst=(-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin))) 
        CT['aconst'] = aconst
        beta= (1.-(temp_r-273.)/578.0)**0.43
        CT['beta'] = beta
        bf.blockfind_CT(temp_r, field, afzero, V, CT)
        V['end_mag'] = 1.0
        field = 0.0
        bf.blockfind_CT(temp_r, field, afzero, V, CT)
        V['end_mag'] = 0.0
        CT['M_2'][var_c, td] = CT['totalm']
        CT['pTRM'][var_c, td] = CT['M_2'][var_c, td] - CT['NRM_r'][var_c, td] 
		
        CT['temp_PI'][var_c, k] = Ttest + 0.1
        CT['mag_PI'][var_c, k] = CT['totalm']
        k+=1		
    

        if (tail_t[td] == 1.):
            while (temp <= Ttest): 
                field = 0.0
                V['heating'] = 1
                CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                CT['beta'] = (1-(temp-273)/578.0)**0.43

                bf.blockfind_CT(temp, field, afzero, V, CT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp + tempstep1
            temp = temp - tempstep1

            while (temp > tempmin): 

                V['heating'] = 0.
                CT['aconst'] = (-ac*60.0*60.0)/(log(0.01*(tempmin)/(tempmax-tempmin)))
                CT['beta'] = (1-(temp-273)/578.0)**0.43
                bf.blockfind_CT(temp, field, afzero, V, CT) 

                if (temp <= 750.):
                    tempstep1 = tempstep*10.
                elif (temp <= 840.) and (temp > 810.):
                    tempstep1 = tempstep/2.
                else:
                    tempstep1 = tempstep
                temp = temp - tempstep1        
        
            temp = temp + tempstep1 

        
            temp_r = 300.1
            CT['beta'] = (1-(temp_r-273)/578.0)**0.43
            bf.blockfind_CT(temp_r, field, afzero, V, CT)
            V['end_mag'] = 1.0
            field = 0.0

            bf.blockfind_CT(temp_r, field, afzero, V, CT)
       
            CT['mag_tail'][var_c, td] = CT['totalm'] 

            V['end_mag'] = 0.0
            CT['temp_tail'][var_c, td] = Ttest
			
            CT['temp_PI'][var_c, k] = Ttest + 0.3
            CT['mag_PI'][var_c, k] = CT['totalm']
            k+=1
			
            t+=1		
		
        td += 1
        Ttest = Ttest_arr[td]


    field = V['field']
    CT['len_a_trm_demag'][var_c] = td 

    CT['hys'] = copy.deepcopy(I['hys'])
    pl.CRM_thermal_demag(CT, SC, V,var_c) 

    pl.TRM_CRM_thermal_demag(TT, CT, SC, V, var_c)
    
    
    pl.NRM_pTRM(CT, TT, V, var_c) #plot NRM vs pTRM for CRM and TRM
    pl.TRM_arai_plot(TT,V,var_c) #plot TRM arai plot
    pl.CRM_arai_plot(CT,V,var_c) #plot CRM arai plot
    
    ac = 1.
    

    
    f= open('{}\{}_{}_prop.txt'.format(dire,variable_change[var_c], var_c), 'w')
    f.write('mean x' + "\t" + str(mu_x) + '\n')
    f.write('max x' + "\t" + str(xmax) + '\n')
    f.write('variance x' + "\t" + str(variance_x) + '\n')
    f.write('stdev x' + "\t" + str(stdev_x) + '\n')
    f.write('stdev y' + "\t" + str(stdev_y) + '\n')
    f.write('mean int field' + "\t" + str(V['mean_int_field'][var_c]) + '\n')    
    f.write('mean y' + "\t" + str(mu_y) + '\n')
    f.write('max y' + "\t" + str(ymax) + '\n')
    f.write('variance y' + "\t" + str(variance_y) + '\n')
    f.write('num hyss in remamance zone' + "\t" + str(V['num_hyss']) + '\n')
    f.write('growth rate' + "\t" + str(g) + '\n')
    f.write('applied field' + "\t" + str(V['field']) + '\n')

    f.write('variable adjusting' + "\t" + str(V['variable_c']) + '\n')
    f.write('variable adjusting value' + "\t" + str(V['variable_change'][var_c]) + '\n')
    f.close()

    f = open('{}\{}_CRM_arai.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_f' + "\t" 'NRM_r' + "\t" + 'pTRM' + "\t" + 'M_2' + '\n')
    for i in range(int(CT['len_a_trm_demag'][var_c])):
        f.write(str(CT['Ttest_list'][var_c, i]) + "\t" + str(CT['Ttest_list'][var_c, i]) + "\t" + str(CT['NRM_r'][var_c][i]) + "\t" + str(CT['pTRM'][var_c][i]) + "\t" + str(CT['M_2'][var_c][i]) + "\n")
    f.close()
    
    f = open('{}\{}_TRM_arai.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_f' + "\t" 'NRM_r' + "\t" + 'pTRM' + "\t" + 'm_2' + '\n')
    for i in range(int(TT['len_a_trm_demag'][var_c])):
        f.write(str(TT['Ttest_list'][var_c, i]) + "\t" + str(TT['Ttest_list'][var_c, i]) + "\t" + str(TT['NRM_r'][var_c][i]) + "\t" + str(TT['pTRM'][var_c][i]) + "\t" + str(TT['M_2'][var_c][i]) + "\n")
    f.close()
	
    f = open('{}\{}_ptrm_TRM.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_ptrm' + "\t" 'NRM_r' + "\t" + 'M3' + "\t" + 'ptrm' + "\t" + 'ptrm tail temp'+ "\t" + 'tail nrm' + '\n')
    for i in range(int(TT['len_a_trm_demag'][var_c])):
        f.write(str(TT['temp_heat'][var_c, i]) + "\t" + str(TT['temp_check'][var_c, i]) + "\t" + str(TT['NRM_check'][var_c][i]) + "\t" + str(TT['pTRM_M3'][var_c][i]) + "\t" + str(TT['pTRM_check'][var_c][i]) + "\t" + str(TT['temp_tail'][var_c][i]) + "\t" + str(TT['mag_tail'][var_c][i]) +  "\n")
    f.close()	
	
	
    f = open('{}\{}_TRM_PI.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'mag' + '\n')
    for i in range(k):
        f.write(str(TT['temp_PI'][var_c, i]) + "\t" + str(TT['mag_PI'][var_c, i]) + "\n")
    f.close()
	
    f = open('{}\{}_CRM_PI.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'mag' + '\n')
    for i in range(k):
        f.write(str(CT['temp_PI'][var_c, i]) + "\t" + str(CT['mag_PI'][var_c, i]) + "\n")
    f.close()	
	
    f = open('{}\{}_ptrm_CRM.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp_nrm' + "\t" + 'temp_ptrm' + "\t" 'NRM_r' + "\t" + 'M3' + "\t" + 'ptrm' + "\t" + "\t" + 'ptrm tail temp'+ "\t" + 'tail nrm' + '\n')
    for i in range(int(CT['len_a_trm_demag'][var_c])):
        f.write(str(CT['temp_heat'][var_c, i]) + "\t" + str(CT['temp_check'][var_c, i]) + "\t" + str(CT['NRM_check'][var_c][i]) + "\t" + str(CT['pTRM_M3'][var_c][i]) + "\t" + str(CT['pTRM_check'][var_c][i]) +  "\t" + str(CT['temp_tail'][var_c][i]) + "\t" + str(CT['mag_tail'][var_c][i]) + "\n")
    f.close()		
	
    f = open('{}/{}_TRM_blockper.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('temp' + "\t" + 'trm' + 'blockper' + '\n')
    for i in range(int(ST['len_a_trm'][var_c])):
        f.write(str(ST['temp_a'][var_c, i]) + "\t" + str(ST['trm_a'][var_c][i]) + "\t" + str(ST['blockper_a'][var_c][i]) + "\n")
    f.close()
	
    f = open('{}/{}CRM_blockper.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('time' + "\t" + 'crm' + 'blockper' + '\n')
    for i in range(int(SC['len_a_crm'][var_c])):
        f.write(str(SC['time_a'][var_c, i]) + "\t" + str(SC['crm_a'][var_c][i]) + "\t" + str(SC['blockper_a'][var_c][i]) + "\n")
    f.close()

    #text file of AF demag data for both
    f= open('{}\{}_AF_demag.txt'.format(dire,variable_change[var_c]), 'w')
    f.write('field step' + "\t" + 'TRM' + "\t" 'CRM' + "\t" + 'SIRM \n')
    for i in range(int(SC['cntfield'])):
        f.write(str(SC['AF_steps'][i]) + "\t" + str(ST['afmag'][var_c][i]) + "\t" + str(SC['afmag'][var_c][i]) + "\t" + str(ST['sirm'][var_c][i]) + "\n")
    f.close()
    
    var_c = var_c +1 #end of loop for testing variable as also used in populating hysterons

#outside main loop


f= open('{}/max_mag.txt'.format(dire), 'w')
f.write('variable value' + "\t" + 'max TRM' + "\t" 'max CRM' + "\t" + ' max SIRM' + '\n')
for var_c in range(int(V['len_var'])):
    f.write(str(V['variable_change'][var_c]) + "\t" + str(ST['max_trm'][var_c]) + "\t" + str(SC['max_crm'][var_c]) + "\t" + str(ST['sirm'][var_c][0]) + "\n")

f.write(str("--- %s seconds ---" % (time.time() - start)))	
f.close()


pl.CRM_TRM_var(SC, ST, V)
pl.SIRM_var(SC, ST, V)

pl.plot_ratios(SC, ST, V)

end = time.time()
print(end - start)




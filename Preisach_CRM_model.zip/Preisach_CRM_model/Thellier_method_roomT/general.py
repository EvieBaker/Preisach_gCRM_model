#import packages
from numba import jit
import numpy as np
from math import acos, pi, sin, cos, sqrt, log, log10, tanh
from scipy.interpolate import interp2d
import random
import matplotlib.pyplot as plt

#constant variables 
mu0 = 4*pi*1e-7
ms0 = 491880.5
kb = 1.3806503e-23
tau = 1e-9
roottwohffield = 2**(0.5)  


eglip=0.54
eglid=log(113*((31486**(-eglip))))+0.52
hf=(10000**(0.54))*(10**(-0.52)) 
eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)
affield = 0
affmax = 0.0
af_step_max = 0.0
flatsub=0
flat=0


afone = 1
afzero = 0


#Arrays for tracking variables and plotting CRM etc
def make_arrays_th_af(ST, SC, V):
    len_var = V['len_var']
    #TRM acquisition
    ST['trm_a'] = np.zeros((len_var, 2000))
    ST['blockper_a'] = np.zeros((len_var, 2000))
	
	
    ST['len_a_trm'] = np.zeros((len_var))
    ST['temp_a'] = np.zeros((len_var, 2000))
    ST['max_trm'] = np.zeros((len_var))

    #CRM acquisition
    SC['crm_a'] = np.zeros((len_var, 8000))
    SC['blockper_a'] = np.zeros((len_var, 8000))
	
    SC['len_a_crm'] = np.zeros((len_var))
    SC['time_a'] = np.zeros((len_var, 8000))
    SC['vol_a'] = np.zeros((len_var, 8000))
    SC['rad_a'] = np.zeros((len_var, 8000))
    SC['max_crm'] = np.zeros((len_var))

    #AF demag steps
    ST['AF_steps'] = np.array([0.0, 2.5, 5., 7.5, 10, 12.5, 15., 17.5, 20., 25., 30., 35., 40., 45., 50., 55., 60., 65., 70., 80., 90., 100.])
    SC['AF_steps'] = ST['AF_steps']


    ST['cntfield'] = len(ST['AF_steps'])
    cntfields = ST['cntfield']
    ST['sirm'] = np.zeros((len_var, cntfields)) 
    ST['afmag'] = np.zeros((len_var, cntfields)) 

    SC['cntfield'] = ST['cntfield']

    SC['sirm'] = np.zeros((len_var, cntfields)) 
    SC['afmag'] = np.zeros((len_var, cntfields)) 

    #TRM model with thermal demag

    ST['trm_a'] = np.zeros((len_var, 2000))
    ST['len_a_trm'] = np.zeros((len_var))
    ST['temp_a'] = np.zeros((len_var, 2000))

    #TRM Thellier methods
    ST['NRM_r'] = np.zeros((len_var, 100))
    ST['pTRM'] = np.zeros((len_var, 100))
    ST['M_2'] = np.zeros((len_var,100))

    ST['demag_field'] = (50E-6)/mu0 
    ST['len_a_trm_demag'] = np.zeros((len_var))
    ST['Ttest_list'] = np.zeros((len_var,100))

    ST['temp_heat'] = np.zeros((len_var, 100))
    ST['temp_check'] = np.zeros((len_var, 100))
    ST['NRM_check'] = np.zeros((len_var, 100))
    ST['pTRM_M3'] = np.zeros((len_var, 100))
    ST['pTRM_check'] = np.zeros((len_var, 100))
    ST['temp_tail'] = np.zeros((len_var, 100))
    ST['mag_tail'] = np.zeros((len_var, 100))
    ST['temp_PI'] = np.zeros((len_var, 100))
    ST['mag_PI'] = np.zeros((len_var, 100))

    #CRM Thellier methods 
    SC['NRM_r'] = np.zeros((len_var, 100))
    SC['pTRM'] = np.zeros((len_var, 100))
    SC['M_2'] = np.zeros((len_var,100))
    SC['Ttest_list'] = np.zeros((len_var,100))

    SC['temp_heat'] = np.zeros((len_var, 100))
    SC['temp_check'] = np.zeros((len_var, 100))
    SC['NRM_check'] = np.zeros((len_var, 100))
    SC['pTRM_M3'] = np.zeros((len_var, 100))
    SC['pTRM_check'] = np.zeros((len_var, 100))
    SC['temp_tail'] = np.zeros((len_var, 100))
    SC['mag_tail'] = np.zeros((len_var, 100))
    SC['temp_PI'] = np.zeros((len_var, 100))
    SC['mag_PI'] = np.zeros((len_var, 100))	
	
	

    SC['demag_field'] = ST['demag_field'] 
    SC['len_a_trm_demag'] = np.zeros((len_var))
    SC['Ttestlist'] = np.zeros((len_var, 100)) 

    V['mean_int_field'] = np.zeros((len_var))

#arrays for anglle variable code
def make_arrays_a(ST, SC, TT, CT, V):
    len_var = V['len_var']

    ST['trm_a'] = np.zeros((len_var, 1000))
    ST['blockper_a'] = np.zeros((len_var, 1000))
    ST['trm_phi_a'] = np.zeros((len_var, 1000))  
    ST['trm_theta_a'] = np.zeros((len_var, 1000))        	
	
    ST['len_a_trm'] = np.zeros((len_var))
    ST['temp_a'] = np.zeros((len_var, 1000))
    ST['max_trm'] = np.zeros((len_var))
    ST['max_trm_phi'] = np.zeros((len_var))     
    ST['max_trm_theta'] = np.zeros((len_var)) 
    
    #plot CRM acquisition
    SC['crm_a'] = np.zeros((len_var, 2000))
    SC['blockper_a'] = np.zeros((len_var, 2000))
    SC['crm_phi_a'] = np.zeros((len_var, 2000))  
    SC['crm_theta_a'] = np.zeros((len_var, 2000))        
	
    SC['len_a_crm'] = np.zeros((len_var))
    SC['time_a'] = np.zeros((len_var, 2000))
    SC['vol_a'] = np.zeros((len_var, 2000))
    SC['rad_a'] = np.zeros((len_var, 2000))
    SC['max_crm'] = np.zeros((len_var))
    SC['max_crm_phi'] = np.zeros((len_var))        
    SC['max_crm_theta'] = np.zeros((len_var)) 
    
    #AF demag steps
    ST['AF_steps'] = np.array([0.0, 2.5, 5., 7.5, 10, 12.5, 15., 17.5, 20., 25., 30., 35., 40., 45., 50., 55., 60., 65., 70., 80., 90., 100.])
    SC['AF_steps'] = ST['AF_steps']

    #arrays for TRM results
    ST['cntfield'] = len(ST['AF_steps'])
    cntfields = ST['cntfield']
    ST['sirm'] = np.zeros((len_var, cntfields))
    ST['afmag'] = np.zeros((len_var, cntfields)) 
    ST['afmag_phi'] = np.zeros((len_var, cntfields)) 
    ST['afmag_theta'] = np.zeros((len_var, cntfields))
    ST['sirm_phi'] = np.zeros((len_var, cntfields)) 
    ST['sirm_theta'] = np.zeros((len_var, cntfields))     

    SC['cntfield'] = ST['cntfield']

    SC['sirm'] = np.zeros((len_var, cntfields)) 
    SC['afmag'] = np.zeros((len_var, cntfields)) 
    SC['afmag_phi'] = np.zeros((len_var, cntfields)) 
    SC['afmag_theta'] = np.zeros((len_var, cntfields)) 
    SC['sirm_phi'] = np.zeros((len_var, cntfields)) 
    SC['sirm_theta'] = np.zeros((len_var, cntfields))  


    TT['trm_a'] = np.zeros((len_var, 1000))
    TT['len_a_trm'] = np.zeros((len_var))
    TT['temp_a'] = np.zeros((len_var, 1000))
    TT['trm_phi_a'] = np.zeros((len_var, 1000))
    TT['trm_theta_a'] = np.zeros((len_var, 1000))    

 
    TT['NRM_r'] = np.zeros((len_var, 100))
    TT['pTRM'] = np.zeros((len_var, 100))
    TT['M_2'] = np.zeros((len_var,100))

    TT['demag_field'] = (50E-6)/mu0 
    TT['len_a_trm_demag'] = np.zeros((len_var))
    TT['Ttest_list'] = np.zeros((len_var,100))

    TT['temp_heat'] = np.zeros((len_var, 100))
    TT['temp_check'] = np.zeros((len_var, 100))
    TT['NRM_check'] = np.zeros((len_var, 100))
    TT['pTRM_M3'] = np.zeros((len_var, 100))
    TT['pTRM_check'] = np.zeros((len_var, 100))
    TT['temp_tail'] = np.zeros((len_var, 100))
    TT['mag_tail'] = np.zeros((len_var, 100))
    TT['temp_PI'] = np.zeros((len_var, 100))
    TT['mag_PI'] = np.zeros((len_var, 100))
    TT['phi_PI'] = np.zeros((len_var, 100))     
    TT['theta_PI'] = np.zeros((len_var, 100))      
    TT['max_trm'] = np.zeros((len_var))     
    


    CT['crm_a'] = np.zeros((len_var, 2000))
    CT['len_a_crm'] = np.zeros((len_var))
    CT['time_a'] = np.zeros((len_var, 2000))
    CT['vol_a'] = np.zeros((len_var, 2000))
    CT['rad_a'] = np.zeros((len_var, 2000))
    CT['crm_phi_a'] = np.zeros((len_var, 2000))
    CT['crm_theta_a'] = np.zeros((len_var, 2000))        
    
 
    CT['NRM_r'] = np.zeros((len_var, 100))
    CT['pTRM'] = np.zeros((len_var, 100))
    CT['M_2'] = np.zeros((len_var,100))
    CT['Ttest_list'] = np.zeros((len_var,100))

    CT['temp_heat'] = np.zeros((len_var, 100))
    CT['temp_check'] = np.zeros((len_var, 100))
    CT['NRM_check'] = np.zeros((len_var, 100))
    CT['pTRM_M3'] = np.zeros((len_var, 100))
    CT['pTRM_check'] = np.zeros((len_var, 100))
    CT['temp_tail'] = np.zeros((len_var, 100))
    CT['mag_tail'] = np.zeros((len_var, 100))
    CT['temp_PI'] = np.zeros((len_var, 100))
    CT['mag_PI'] = np.zeros((len_var, 100))	
    CT['phi_PI'] = np.zeros((len_var, 100))     
    CT['theta_PI'] = np.zeros((len_var, 100))   
    CT['max_crm'] = np.zeros((len_var))     
	
	

    CT['demag_field'] = TT['demag_field'] 
    CT['len_a_trm_demag'] = np.zeros((len_var))
    CT['Ttestlist'] = np.zeros((len_var, 100)) 

    V['mean_int_field'] = np.zeros((len_var))


#function to determine the probability density function at each point in the Preisach distribution     
def inter_rho_C(xi_s_f, yi_s_f, zi_s_f, hys, i):
    xi1_row = xi_s_f[0,:] 
    up_hc = xi1_row[xi1_row > hys[i,0]].min()  
    lo_hc = xi1_row[xi1_row < hys[i,0]].max() 
    up_hc_idx = list(xi1_row).index(up_hc) 
    lo_hc_idx = list(xi1_row).index(lo_hc)
    yi1_col = yi_s_f[:,0] 

    up_hi = yi1_col[yi1_col > hys[i,1]].min() 
    lo_hi = yi1_col[yi1_col < hys[i,1]].max() 

    up_hi_idx = list(yi1_col).index(up_hi) 
    lo_hi_idx = list(yi1_col).index(lo_hi)

    x_arr = np.array([xi_s_f[lo_hi_idx,lo_hc_idx], xi_s_f[up_hi_idx, lo_hc_idx], xi_s_f[up_hi_idx, up_hc_idx], xi_s_f[lo_hi_idx, up_hc_idx]])
    y_arr = np.array([yi_s_f[lo_hi_idx,lo_hc_idx], yi_s_f[up_hi_idx, lo_hc_idx], yi_s_f[up_hi_idx, up_hc_idx], yi_s_f[lo_hi_idx, up_hc_idx]])
    z_arr = np.array([zi_s_f[lo_hi_idx,lo_hc_idx], zi_s_f[up_hi_idx, lo_hc_idx], zi_s_f[up_hi_idx, up_hc_idx], zi_s_f[lo_hi_idx, up_hc_idx]])

    f = interp2d(x_arr, y_arr, z_arr, kind='linear')
    
    hys[i,3] = f(hys[i,0], hys[i,1]) 
    return hys
    
    
#populate each hysteron with a randon easy axis angle 
@jit(nopython = True)       
def hys_angles_C():
    
    angle = random.random()
    phi = acos(2*angle - 1) 
    if(phi > (pi/2.)): 
        phi = pi-phi
    angle2 = random.random()
    phistatic = acos(2*angle2 - 1)
    if(phistatic > (pi/2.)):
        phistatic = pi-phistatic
    
    angle3 = random.random()
    thetastatic = 2*pi*angle3
    return phi, phistatic, thetastatic

#calculate Hk for each hysteron from Hc using interpolated equation from Muxworthy and Heslop 2011 + Pfeiffer 1990
@jit(nopython = True)  
def calc_hk_arrays_C(hys, num, tm, ms): 
    hc = hys[:,0] 
    tempt = 300.
    
    hf = ((hc/(sqrt(2)))**(eglip))*(10**(-0.52)) 
 
    phi = np.copy(hys[:,5]) 
    phi[:] = 1.24616508592395
    phitemp = (((np.sin(phi))**(2./3.))+((np.cos(phi))**(2./3.)))**(-3./2.) 

    gphitemp = (0.86 + (1.14*phitemp)) 
  
    hatmp = hc/(sqrt(2))
  
  
    ht = hf*(log(tm/tau))
    
    hktmp = hatmp +ht + (2*hatmp*ht+ht**2)**0.5
    hktmpstore = hktmp
    i=0
    for i in range(int(num)):
        factor = 0.5
        searchme = 1000000.0     
        hstep = (hktmp[i]-hatmp[i])/5.

        while (abs(searchme)> 5):
            searchme = hktmp[i] - hatmp[i] - hktmp[i]*((2*ht[i]*phitemp[i]/hktmp[i])**(1/gphitemp[i])) #
            hktmpstore[i] = hktmp[i]
        
            if (searchme > 0):
                hktmp[i] = hktmp[i] - hstep
            else:
                hktmp[i] = hktmp[i] + hstep
                hstep = hstep*factor

    hkphi = hktmpstore 
    hk = hkphi/phitemp

    hys[:,9] = hk 
    kb=1.3806503e-23 
    
    hys[:,11] = (kb*tempt)/(mu0*ms) 
    v_act = (kb*tempt)/(hf*mu0*ms)
    vol = v_act/(1 - (((hys[:,0])/sqrt(2))/hk))
    hys[:,10] = vol
    
    return(hys)
#populate hysterons with negative interactions in symmetrical fashion 
@jit(nopython = True)  
def num_p(hys, num_pop):
    j=0
    for j in range(num_pop):
        hys[(j+num_pop),:] = hys[j,:]
        hys[j+num_pop,1] = -hys[j,1]
        j+=1
    return hys

#populate the hysterons with properties 
def pop_hys(num_hys, V, SC): 

    tm = SC['tm']
    ms = SC['ms']
    hys = np.zeros((num_hys,12)) 

    num_pop = num_hys/2

    xi_s_cut = SC['x']/mu0
    yi_s_cut = SC['y']/mu0
    zi_s_cut = SC['z_n'] 
    maxHc = np.nanmax(xi_s_cut)
    maxHi = np.nanmax(yi_s_cut)
   
    i=0
    while (i < int(num_pop)):
        z2 = random.random()
        z3 = random.random()
  
        hys[i,0] = (z2*maxHc)

        hys[i,1] = (z3*maxHi)
        

        hys = inter_rho_C(xi_s_cut, yi_s_cut, zi_s_cut, hys, i) 
        hys[i,1] = hys[i,1]
        hys[i,5], hys[i,6], hys[i,7] = hys_angles_C() 
      
        if (hys[i,3] >= 0) and (hys[i,3] <= 1) and (hys[i,1] <= hys[i,0]) and (hys[i,0] > 1000):     
            i +=1 
        
    hys = calc_hk_arrays_C(hys, int(num_pop), tm ,ms) 
    hys[:,4] = 1
 
    hys[:,8] = hys[:,5]*hys[:,4] 
    num_pop = int(num_pop)

    hys = num_p(hys, num_pop)

    return hys, num_pop

#angle version of populating hysterons in 3D not 2D
@jit(nopython = True)  
def num_p_a(hys, angles, num_pop):
    j=0
    for j in range(num_pop):
        hys[(j+num_pop),:] = hys[j,:]
        angles[(j+num_pop),:] = angles[j,:]
        hys[j+num_pop,1] = -hys[j,1]
        j+=1
    return hys, angles

#3D version of populating hysterons
def pop_hys_a(num_hys, V, SC): 
    tm = SC['tm']
    ms = SC['ms']
    hys = np.zeros((num_hys,13)) 

    angles = np.zeros((num_hys,9))
    num_pop = num_hys/2
    

    xi_s_cut = SC['x']/mu0
    yi_s_cut = SC['y']/mu0
    zi_s_cut = SC['z_n'] 
    maxHc = np.nanmax(xi_s_cut)  
    maxHi = np.nanmax(yi_s_cut)
   
    i=0
    while (i < int(num_pop)):
        z2 = random.random()
        z3 = random.random()
  
        hys[i,0] = (z2*maxHc)

        hys[i,1] = (z3*maxHi)


        hys = inter_rho_C(xi_s_cut, yi_s_cut, zi_s_cut, hys, i) 
        hys[i,1] = hys[i,1]
        hys[i,5], hys[i,6], hys[i,7] = hys_angles_C() 
        angles[i,0] = hys[i,5]

        z4 = random.random()
        long = z4*2.*pi
        hys[i,12] = long
        angles[i,1] = hys[i,12] 
        
        angles[i,2] = 1.
        angles[i,3] = 1.
        angles[i,4] = 1.
        angles[i,5] = np.sin(angles[i,0])*np.cos(angles[i,1])
        angles[i,6] = np.sin(angles[i,0])*np.sin(angles[i,1])        
        angles[i,7] = np.cos(angles[i,0])  
        angles[i,5] = angles[i,5]/sqrt(angles[i,5]**2+angles[i,6]**2 + angles[i,7]**2)
        angles[i,6] = angles[i,6]/sqrt(angles[i,5]**2+angles[i,6]**2 + angles[i,7]**2)        
        angles[i,7] = angles[i,7]/sqrt(angles[i,5]**2+angles[i,6]**2 + angles[i,7]**2) 

        if (hys[i,3] >= 0) and (hys[i,3] <= 1) and (hys[i,1] <= hys[i,0]) and (hys[i,0] > 1000):     
            i +=1 
        
    hys = calc_hk_arrays_C(hys, int(num_pop), tm ,ms) 
    hys[:,4] = 1
 
    hys[:,8] = hys[:,5]*hys[:,4] 
    num_pop = int(num_pop)

    hys, angles = num_p_a(hys, angles, num_pop)

    return hys, num_pop, angles

#number of blocked hysterons at room temperature 
def blocked_hys(I, V):
    hys_pre = np.copy(I['hys'])
    hys_new = np.zeros_like(hys_pre)
    hys_block = np.zeros_like(hys_pre)
	
    ms = I['ms']
    t_vol_a = hys_pre[:,10]*hys_pre[:,3]
    t_vol = sum(t_vol_a)

    i=0
    j=0
    k=0
    beta = (1-(300-273)/578.0)**0.43
    temp = 300

    for i in range(len(hys_new)):
        phitemp=((sin(hys_pre[i,5])**(2./3.))+(cos(hys_pre[i,5])**(2./3.)))**(-3./2.) 
        hc=(sqrt(2))*(hys_pre[i,9]*beta)
        hi = hys_pre[i,1]*beta

        g=0.86+1.14*phitemp

        v_co = (1 - ((abs(hi/sqrt(2)))/hys_pre[i,9]*beta))
        v_act_c = hys_pre[i,10]*v_co


       
        hf = (kb*temp)/(ms*mu0*v_act_c)

        tm = 60.0
        ht = (roottwohffield)*hf*(log(tm/tau))
        field = 0.0
        bracket = 1-(2*ht*phitemp/hc)**(1/g)
        hiflipplus = hc*bracket
        hiflipminus=-hc*bracket
		
        if (hc >= (2*ht*phitemp)):
            if ((hi > hiflipminus) and (hi < hiflipplus)):
                hys_new[j,:] = hys_pre[i,:]
                j+=1
    i+=1


    hys_new = hys_new[hys_new[:,0] > 0.00000000001]
    
    vol_rem_a = hys_new[:,10]*hys_new[:,3]
    vol_rem = sum(vol_rem_a)
    V['vol_rem'] = vol_rem
    print('all sum= ', t_vol_a, ' blocked sum= ', vol_rem)
    I['hys'] = hys_pre
    return(I,V)


#norm Preisach distribution 
def norm_z(ST, SC, I, i):
    z_pre_norm = ST['z']
    maxval_z = np.nanmax(z_pre_norm)
    z_norm = (z_pre_norm)/(maxval_z)
    ST['z_n'] = z_norm
    SC['z_n'] = z_norm
    I['z_n'] = z_norm
    return

def norm_z_HT(V, TC_A, TC_T, I, i):
    z_pre_norm = TC_A['z']

    maxval_z = np.nanmax(z_pre_norm)
    z_norm = (z_pre_norm)/(maxval_z)

    TC_A['z_n'] = z_norm
    TC_T['z_n'] = z_norm
    I['z_n'] = z_norm
    return

#TRM acquisition - location of each hysteron in Preisach space 
@jit(nopython = True)
def block_loc_T(var_1, hys, blockg, boltz):

    num_hyss = int(var_1[0])
    beta = float(var_1[1])
    blockper = float(var_1[2])
    temp = float(var_1[3])
    aconst = float(var_1[4])
    ms = float(var_1[5])
    rate = float(var_1[6])    
    tempmin = float(var_1[7])
    field = float(var_1[8])
    tm = float(var_1[9])
    end_mag = float(var_1[10])
    heating = float(var_1[11])



    tau = 1e-9
    kb = 1.3806503e-23 
    roottwohffield = 2**(0.5)
    hfstore = np.zeros((num_hyss))
    histore = np.zeros((num_hyss))    
    hcstore = np.zeros((num_hyss))   
    blocktemp = np.zeros((num_hyss))
    i=0 

    for i in range(num_hyss): 

        phitemp=((sin(hys[i,5])**(2./3.))+(cos(hys[i,5])**(2./3.)))**(-3./2.)          
        hc=(sqrt(2))*(hys[i,9]*beta)       
        hcstore[i] = hc/(sqrt(2)) 

        hi = hys[i,1]*beta*blockper  
        histore[i] = hi/(sqrt(2)) 
    
        g=0.86+1.14*phitemp

        h_hs = field - histore[i]
        v_co = (1 - ((abs(h_hs))/(hys[i,9]*beta)))

        if (v_co <= 0):
            v_co = 0.00001
        v_act_c = hys[i,10]*v_co

  
    
        hf = (kb*temp)/(ms*mu0*v_act_c)
        hfstore[i] = hf 

    
        dt = 10.
        r = 1.
        if (rate == 1): 
            
    
            r = (1./aconst)*(temp-tempmin) #r is cooling rate

            tm = (temp/r)*(1 - (temp/(578+273)))/log((2*temp)/(tau*r)*((1. - (temp/(578+273)))))

            

    
            if (tm == 0.0): 
                tm = 60.0
        if (end_mag == 1.0):
            tm = 60.0
        
        ht = (roottwohffield)*hf*(log(tm/tau)) 

        bracket = 1-(2*ht*phitemp/hc)**(1/g)
        
        hiflipplus = hc*bracket+field*(roottwohffield) 
    
        hiflipminus=-hc*bracket+field*(roottwohffield) 

    
        if (hc >= (2*ht*phitemp)): #checking location in Preisach space using equations in Muxworthy + Heslop 2011 at each temp step

            if ((hi > hiflipminus) and (hi < hiflipplus)):
    
                
                if ((blockg[i] == 0) or (blockg[i] == 2) or (blockg[i] == -2)):
 
                    if (hi >= (field*roottwohffield)): 
  
                        blocktemp[i] = -1
                        
                    else:
                        blocktemp[i] = 1 
                        
                elif (blockg[i] == -1): 

                    blocktemp[i] = -1
            

                elif (blockg[i] == 1):
 
                    blocktemp[i] = 1
                    
                else:

                    print(blockg[i], blocktemp[i]) 

            elif (hi >= hiflipplus):

                blocktemp[i] = -2
                if (heating == 1):
                    boltz[i] = 0.0 
                
            else:
 
                blocktemp[i] = 2
                if (heating == 1):
                    boltz[i] = 0.0 

        else: 

    
            if ((hi < hiflipminus) and (hi > hiflipplus)): 
                
                blocktemp[i] = 0
                if (heating == 1):
                    boltz[i] = 0.0
       
            else:
                if (hi >= hiflipminus):

                    blocktemp[i] = -2
                    if (heating == 1):
                        boltz[i] = 0.0 
                else:
 
                    blocktemp[i] = 2
                    if (heating == 1):
                        boltz[i] = 0.0 

    return hfstore, histore, boltz, blocktemp

#function to determine percentage alignment with the field if blocked at this temperaure step 
@jit(nopython = True)
def block_val_T(hys, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem):

    totalm = 0.0
    totalmoment = 0
    i=0
    blockper = 0.
    
    for i in range(num_hyss):

        blockg[i] = blocktemp[i]
        absblockg = abs(blockg[i])

        if (absblockg == 1): 
            if (boltz[i] < 0.00000001) and (boltz[i] > -0.000000001): 
     

                boltz[i] = tanh((field - histore[i])/hfstore[i])
                
                if (afswitch == 1):
                   # print('inside tanh reset during af demag', (((50E-6/mu0) - histore[i])/hfstore[i]))
                    boltz[i] = 0.
                   # print('boltz reset during af demag - expect mean reblock', boltz[i])
               
        if (blockg[i] == -2):
            moment = -0 

        elif (blockg[i] == 2):
            moment = 0

        else:
            moment = blockg[i] 

 
        #AF demag calc
      
        if (afswitch == 1): #afswtich given in function, 1 or 0

            hi = histore[i]*(sqrt(2))
            hc = (sqrt(2))*(hys[i,9]*beta)*(((sin(hys[i,6])**(2./3.))+(cos(hys[i,6])**(2./3.)))**(-3./2.))
    
            af = afstore/(1000*mu0) 
        
            
            if (hi >=0) and (hi > (hc-af)): 
                moment = 0
               
                boltz[i] = 0
                blockg[i] = -2
            
        
            if (hi <= 0) and (hi < (-hc + af)):
                moment = 0
                blockg[i] = 2
                boltz[i] = 0
    
        
        totalm = totalm + (abs(moment)*abs(cos(hys[i,5]))*beta*(boltz[i])*((hys[i,3]*hys[i,10])/max_total)) 

        if (blockg[i] == -1) or (blockg[i] == 1):
            moment_block = 1
        else:
            moment_block = 0
		
        blockper=blockper+ ((abs(moment_block))*hys[i,10]*hys[i,3])
        totalmoment=totalmoment+moment

    if (blockper != 0):

        blockper= (blockper)/(vol_rem)
    else:
        blockper = 1E-15

    return blockper, totalm, boltz, blockg

#Location of hysterons in Preisach space in CRM acquistion called at each time step 
@jit(nopython = True)
def block_loc_C(var_1, hys, prop, blockg, boltz):

    num_hyss = int(var_1[0])
    beta = float(var_1[1])
    blockper = float(var_1[2])
    temp = float(var_1[3])
    t = float(var_1[4])
    tstep = float(var_1[5])
    rate = float(var_1[6])    
    field = float(var_1[7])
    tm = float(var_1[8])
    end_mag = float(var_1[9])

    tau = 1e-9
 
    roottwohffield = 2**(0.5)
    hfstore = np.zeros((num_hyss))
    histore = np.zeros((num_hyss))    
    hcstore = np.zeros((num_hyss))   
    blocktemp = np.zeros((num_hyss))
    i=0 
    for i in range(num_hyss): 
        if (t >= (prop[i,3] + (0.5*tstep))):

            phitemp=((sin(hys[i,5])**(2./3.))+(cos(hys[i,5])**(2./3.)))**(-3./2.)              
            hc=(sqrt(2))*(hys[i,9]*beta) 
            
            hcstore[i] = hc/(sqrt(2)) 
        
            
            hi = hys[i,1]*beta*blockper 
            
    
            histore[i] = hi/(sqrt(2)) 

            g=0.86+1.14*phitemp
    
            h_hs = field - histore[i]
            v_co = (1 - ((abs(h_hs))/(hys[i,9]*beta)))
            if (v_co <= 0):
                v_co = 0.00001               
            
            v_act_c = prop[i,5]*v_co

            hf = hys[i,11]*(1/(v_act_c))
        
            hfstore[i] = hf 

            if (rate == 1): 
                
                tm= prop[i,10]
                
                if (tm == 0.0): 
                    tm = 60.0

            if (end_mag == 1.0):
                tm = 60.0
            ht = (roottwohffield)*hf*(log(tm/tau)) 
        
            
            bracket = 1-(2*ht*phitemp/hc)**(1/g)
            
            hiflipplus = hc*bracket+field*(roottwohffield) 
    
            hiflipminus=-hc*bracket+field*(roottwohffield)
            trialtemp=0

            if (hc >= (2*ht*phitemp)): 

                if ((hi > hiflipminus) and (hi < hiflipplus)):

                    if (blockg[i] == 0) or (blockg[i] == 2) or (blockg[i] == -2): 
                        
                        if (hi >= (field*roottwohffield)): #+4
                            
                            blocktemp[i] = -1
                            
                        else:
          
                            blocktemp[i] = 1 
                            
                    elif (blockg[i] == -1):
                        
                        blocktemp[i] = -1
                

                    elif (blockg[i] == 1):
                        blocktemp[i] = 1

                elif (hi >= hiflipplus):

                    blocktemp[i] = -2
                
                    
                else:
                    blocktemp[i] = 2

            else: 

        
                if ((hi < hiflipminus) and (hi > hiflipplus)): 
                    blocktemp[i] = 0
                else: 
                    if (hi >= hiflipminus):
                        blocktemp[i] = -2

                    else:

                        blocktemp[i] = 2

            if (temp < trialtemp):

                print('blocktemp', blocktemp[i])
                
    return hfstore, histore, boltz, blocktemp

#find effective time for each CRM step and hysteron
@jit(nopython = True)
def find_tm(prop, num_hyss, t, g, Ro, eul, tau, tstep):  
    l=0
    for l in range(int(num_hyss)): 

        if (t >= (prop[l,3] + (0.5*tstep))) : #time grater than nucleation time, less than final growth time

            prop[l,4] = Ro + g*(t - prop[l,3]) #current radius

            prop[l,11] = prop[l,5] #prev volume before change it
            prop[l,5] = ((4*pi)/3.)*(prop[l,4])**3  #volume current
            Vdot = (4*pi*g*(prop[l,4])**2) #rate volume growth
            prop[l,10] = ((eul*prop[l,5])/Vdot)/(log((eul*prop[l,5])/(tau*Vdot))) # use Vdot here and overwrite for next time
        l+=1
    return prop


#function to determine percentage alignment with the field if blocked at this time step 
@jit(nopython = True)
def block_val_C(hys, prop, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, t, tstep):

    totalm = 0.0
    totalmoment = 0

    i=0

    blockper = 0.
    for i in range(num_hyss):

        
        blockg[i] = blocktemp[i]
        absblockg = abs(blockg[i])
        if (t >= (prop[i,3] + (0.5*tstep))):
           
            if (absblockg == 1): 
                if (boltz[i] < 0.00000001) and (boltz[i] > -0.000000001): #only zero

                    boltz[i] = tanh((field - histore[i])/hfstore[i])
                    if (afswitch == 1):

                        boltz[i] = 0.

            if (blockg[i] == -2):

                moment = -0 
            elif (blockg[i] == 2):

                moment = 0
            else:

                moment = blockg[i] 


            
            
            if (afswitch == 1):

                hi = histore[i]*(sqrt(2))
                hc = (sqrt(2))*(hys[i,9]*beta)*(((sin(hys[i,6])**(2./3.))+(cos(hys[i,6])**(2./3.)))**(-3./2.))
        
                af = afstore/(1000*mu0)
                if (hi >= 0) and (hi > (hc-af)):
                    moment = 0
                    blockg[i] = -2

                    boltz[i] = 0.
                if (hi <= 0) and (hi < (-hc + af)):
                    moment = 0
                    blockg[i] = 2

                    boltz[i] = 0.0
            totalm = totalm + (abs(moment)*abs(cos(hys[i,5]))*beta*(boltz[i])*((hys[i,3]*prop[i,5])/max_total)) 

            if (blockg[i] == -1) or (blockg[i] == 1):
                moment_block = 1
            else:
                moment_block = 0
		
            blockper=blockper+ ((abs(moment_block))*prop[i,5]*hys[i,3]) 
            totalmoment=totalmoment+moment
        

    if (blockper != 0.):
        blockper= (blockper)/(vol_rem)
    else:

        blockper = 1E-15
    return blockper, totalm, boltz, blockg
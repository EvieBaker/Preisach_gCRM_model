#import packages
from numba import jit
import numpy as np
from math import acos, pi, sin, cos, sqrt, log, log10, tanh
from scipy.interpolate import interp2d
import random
import matplotlib.pyplot as plt

import general as ge
#constant variables 
mu0 = 4*pi*1e-7
ms0 = 491880.5
kb = 1.3806503e-23
tau = 1e-9
roottwohffield = 2**(0.5)  


eglip=0.54
hf=(10000**(0.54))*(10**(-0.52)) 
eglid=+0.52+(log10(hf)-log10(10000.0)*eglip)
affield = 0
affmax = 0.0
af_step_max = 0.0
flatsub=0
flat=0


afone = 1
afzero = 0


#determines which particles are blocked
def blockfind_ST(temp, field, afswitch, V, ST):

    hys = ST['hys']
    num_hyss = V['num_hyss']
    hcstore = ST['hcstore']
    histore = ST['histore']
    beta = ST['beta']
    rate = ST['rate']
    aconst = ST['aconst']
    tempmin = V['tempmin']
    sense = ST['sense']
    
    vol_rem = V['vol_rem']

    max_total_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_a)
    
    tempmin = V['tempmin']
    
    tm = ST['tm'] 

    ms = ms0*beta 
    conv=(mu0*1000)/(sqrt(2))
   
    af_step = ST['AF_steps']
 

    blockper = ST['blockper'] 
    countiold = ST['countiold']

    blocktemp = ST['blocktemp'] 
    boltz = ST['boltz']
    blockg = ST['blockg']

    heating = V['heating']

    totalm = ST['totalm']
    end_mag = V['end_mag']
    afstore = ST['afstore']

  

    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating))

    hfstore, histore, boltz, blocktemp = ge.block_loc_T(var_1, hys, blockg, boltz) #location each hysteron in preisach space
  
    blockper, totalm, boltz, blockg = ge.block_val_T(hys, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem) #boltz if blocking
    
    
    ST['aftotalm'] = totalm
    ST['sir'] = totalm
 
    ST['blockper'] = blockper
    ST['countiold'] = countiold 
    ST['blocktemp'] = blocktemp
    ST['boltz'] = boltz
    ST['blockg'] = blockg
    ST['totalm'] = totalm


    ST['tm'] = tm
    ST['sense'] = sense
   

    return 



#blockfind for CRM acquisition called at each time step
def blockfind_SC(t, field, afswitch, V, SC): 

    hys = SC['hys']
    prop = SC['prop']
   
    max_total_m_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_m_a)
	
    vol_rem = V['vol_rem']
	
    num_hyss = V['num_hyss']

    histore = SC['histore']
    beta = SC['beta']
    rate = SC['rate']

    sense = SC['sense']
    tm = SC['tm'] 
    tstep = SC['tstep']
    
    temp = SC['temp']

   
    hfstore = np.zeros(num_hyss)


    blockper = SC['blockper'] 
    countiold = SC['countiold']

    blocktemp = SC['blocktemp'] 
    boltz = SC['boltz']
    blockg = SC['blockg']

    end_mag = V['end_mag']

    totalm = SC['totalm']
    afstore = SC['afstore']




    var_1 = np.array((num_hyss, beta, blockper, temp, t, tstep, rate, field, tm, end_mag))

    hfstore, histore, boltz, blocktemp = ge.block_loc_C(var_1, hys, prop, blockg, boltz) #hysteron locations in Preisach space 
  
    blockper, totalm, boltz, blockg = ge.block_val_C(hys, prop, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, t, tstep) #blocked properties
 
    SC['aftotalm'] = totalm
    SC['sir'] = totalm

    SC['blockper'] = blockper
    SC['countiold'] = countiold 
    SC['blocktemp'] = blocktemp
    SC['boltz'] = boltz
    SC['blockg'] = blockg
    SC['totalm'] = totalm

    SC['tm'] = tm
    SC['sense'] = sense

    return #totalm    



#Thellier on TRM - TT function called at each temperature step 
def blockfind_TT(temp, field, afswitch, V, TT): 

    hys = TT['hys']
    num_hyss = V['num_hyss']
    hcstore = TT['hcstore']
    histore = TT['histore']
    beta = TT['beta']
    rate = TT['rate']
    aconst = TT['aconst']
    tempmin = V['tempmin']
    sense = TT['sense']
    
    vol_rem = V['vol_rem']

    max_total_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_a)
    
    tempmin = V['tempmin']
    
    tm = TT['tm'] 

    ms = ms0*beta 
    conv=(mu0*1000)/(sqrt(2))
   
    af_step = TT['AF_steps']
    

    blockper = TT['blockper'] 
    countiold = TT['countiold']
    blocktemp = TT['blocktemp'] 
    boltz = TT['boltz']
    blockg = TT['blockg']
    heating = V['heating']

    totalm = TT['totalm']
    end_mag = V['end_mag']
    afstore = TT['afstore']



    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating))

    hfstore, histore, boltz, blocktemp = ge.block_loc_T(var_1, hys, blockg, boltz)
  
    blockper, totalm, boltz, blockg = ge.block_val_T(hys, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem)
    
    
    TT['aftotalm'] = totalm
    TT['sir'] = totalm

    TT['blockper'] = blockper
    TT['countiold'] = countiold 
    TT['blocktemp'] = blocktemp
    TT['boltz'] = boltz
    TT['blockg'] = blockg
    TT['totalm'] = totalm

    TT['tm'] = tm
    TT['sense'] = sense
   

    return #totalm

#Blockfind for CRMs during Thellier process
def blockfind_CT(temp, field, afswitch, V, CT): 

    hys = CT['hys']
    num_hyss = V['num_hyss']
    hcstore = CT['hcstore']
    histore = CT['histore']
    beta = CT['beta']
    rate = CT['rate']
    aconst = CT['aconst']
    tempmin = V['tempmin']
    sense = CT['sense']
    
    vol_rem = V['vol_rem']

    max_total_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_a)
    
    tempmin = V['tempmin']
    
    tm = CT['tm']

    ms = ms0*beta 
    conv=(mu0*1000)/(sqrt(2))
   
    af_step = CT['AF_steps']
    

    blockper = CT['blockper'] 
    countiold = CT['countiold']
    blocktemp = CT['blocktemp'] 
    boltz = CT['boltz']
    blockg = CT['blockg']

    heating = V['heating']

    totalm = CT['totalm']
    end_mag = V['end_mag']
    afstore = CT['afstore']


    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating))

    hfstore, histore, boltz, blocktemp = ge.block_loc_T(var_1, hys, blockg, boltz)
  
    blockper, totalm, boltz, blockg = ge.block_val_T(hys, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem)
    
    
    CT['aftotalm'] = totalm
    CT['sir'] = totalm
    CT['blockper'] = blockper
    CT['countiold'] = countiold 
    CT['blocktemp'] = blocktemp
    CT['boltz'] = boltz
    CT['blockg'] = blockg
    CT['totalm'] = totalm
    CT['tm'] = tm
    CT['sense'] = sense
   

    return 


#blockfind for HCRMs 
def blockfind_TC_A(t, field, afswitch, V, TC_A):

    hys = TC_A['hys']
    prop = TC_A['prop']
   
    max_total_m_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_m_a)
	
    vol_rem = V['vol_rem']
	
    num_hyss = V['num_hyss']

    histore = TC_A['histore']
    beta = TC_A['beta']
    rate = TC_A['rate']

    sense = TC_A['sense']
    tm = TC_A['tm'] 
    tstep = TC_A['tstep']
    
    temp = TC_A['temp']

   
    hfstore = np.zeros(num_hyss)

    blockper = TC_A['blockper'] 
    countiold = TC_A['countiold']

    blocktemp = TC_A['blocktemp'] 
    boltz = TC_A['boltz']
    blockg = TC_A['blockg']

    end_mag = V['end_mag']

    totalm = TC_A['totalm']
    afstore = TC_A['afstore']


    var_1 = np.array((num_hyss, beta, blockper, temp, t, tstep, rate, field, tm, end_mag))

    hfstore, histore, boltz, blocktemp = ge.block_loc_C(var_1, hys, prop, blockg, boltz)
  
    blockper, totalm, boltz, blockg = ge.block_val_C(hys, prop, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem, t, tstep)
 
    TC_A['aftotalm'] = totalm
    TC_A['sir'] = totalm
    TC_A['blockper'] = blockper
    TC_A['countiold'] = countiold 
    TC_A['blocktemp'] = blocktemp
    TC_A['boltz'] = boltz
    TC_A['blockg'] = blockg
    TC_A['totalm'] = totalm

    TC_A['tm'] = tm
    TC_A['sense'] = sense

    return  

#Blockfind for TCRMs 
def blockfind_TC_AT(temp, field, afswitch, V, TC_A): 

    hys = TC_A['hys']
    num_hyss = V['num_hyss']
    hcstore = TC_A['hcstore']
    histore = TC_A['histore']
    beta = TC_A['beta']
    rate = TC_A['rate']
    aconst = TC_A['aconst']
    tempmin = V['tempmin']
    sense = TC_A['sense']
    
    vol_rem = V['vol_rem']

    max_total_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_a)
    
    tempmin = V['tempmin']
    
    tm = TC_A['tm'] 

    ms = ms0*beta 
    conv=(mu0*1000)/(sqrt(2))
   
    af_step = TC_A['AF_steps']

    blockper = TC_A['blockper'] 
    countiold = TC_A['countiold']
    blocktemp = TC_A['blocktemp'] 
    boltz = TC_A['boltz']
    blockg = TC_A['blockg']
    heating = V['heating']

    totalm = TC_A['totalm']
    end_mag = V['end_mag']
    afstore = TC_A['afstore']


    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating))

    hfstore, histore, boltz, blocktemp = ge.block_loc_T(var_1, hys, blockg, boltz)
  
    blockper, totalm, boltz, blockg = ge.block_val_T(hys, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem)
    
    
    TC_A['aftotalm'] = totalm
    TC_A['sir'] = totalm

    TC_A['blockper'] = blockper
    TC_A['countiold'] = countiold 
    TC_A['blocktemp'] = blocktemp
    TC_A['boltz'] = boltz
    TC_A['blockg'] = blockg
    TC_A['totalm'] = totalm
    TC_A['tm'] = tm
    TC_A['sense'] = sense
   

    return 

#Thellier part 
def blockfind_TC_T(temp, field, afswitch, V, TC_T): 

    hys = TC_T['hys']
    num_hyss = V['num_hyss']
    hcstore = TC_T['hcstore']
    histore = TC_T['histore']
    beta = TC_T['beta']
    rate = TC_T['rate']
    aconst = TC_T['aconst']
    tempmin = V['tempmin']
    sense = TC_T['sense']
    
    vol_rem = V['vol_rem']

    max_total_a = hys[:,10]*hys[:,3]
    max_total = sum(max_total_a)
    
    tempmin = V['tempmin']
    
    tm = TC_T['tm'] 

    ms = ms0*beta
    conv=(mu0*1000)/(sqrt(2))
   
    af_step = TC_T['AF_steps']
    

    blockper = TC_T['blockper'] 
    countiold = TC_T['countiold']
    blocktemp = TC_T['blocktemp'] 
    boltz = TC_T['boltz']
    blockg = TC_T['blockg']
    heating = V['heating']

    totalm = TC_T['totalm']
    end_mag = V['end_mag']
    afstore = TC_T['afstore']


    var_1 = np.array((num_hyss, beta, blockper, temp, aconst, ms, rate, tempmin, field, tm, end_mag, heating))

    hfstore, histore, boltz, blocktemp = ge.block_loc_T(var_1, hys, blockg, boltz)
  
    blockper, totalm, boltz, blockg = ge.block_val_T(hys, histore, hfstore, blocktemp, beta, num_hyss, boltz, blockg, field, afswitch, afstore, max_total, vol_rem)
    
    
    TC_T['aftotalm'] = totalm
    TC_T['sir'] = totalm
    TC_T['blockper'] = blockper
    TC_T['countiold'] = countiold 
    TC_T['blocktemp'] = blocktemp
    TC_T['boltz'] = boltz
    TC_T['blockg'] = blockg
    TC_T['totalm'] = totalm
    TC_T['tm'] = tm
    TC_T['sense'] = sense
   

    return


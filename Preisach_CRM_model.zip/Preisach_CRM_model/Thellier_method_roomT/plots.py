#PLOTS
import numpy as np
from math import acos, pi, sin, cos, sqrt, log, log10, tanh
from scipy.interpolate import interp2d
import random
import matplotlib.pyplot as plt

mu0 = 4*np.pi*1E-7

def plot_CRM_acquired_time(V, SC, var_c):

    err_c = SC['err_c']
    crm_a = SC['crm_a']
    len_a_crm = SC['len_a_crm']
    time_a = SC['time_a']
    name = V['name']
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    
    crm_a_err = np.zeros_like(crm_a) 
    crm_a_err = err_c*crm_a 
    i = var_c
    dire = V['dir']
    plt.plot(time_a[i][:int(len_a_crm[i])]/(60*60.), crm_a[i][:int(len_a_crm[i])], marker = 'o')
    plt.errorbar(time_a[i][:int(len_a_crm[i])]/(60*60.), crm_a[i][:int(len_a_crm[i])], yerr = crm_a_err[i][:int(len_a_crm[i])]) #plot error bars
    plt.autoscale()
    plt.ylabel('CRM')
    plt.xlabel('time (hr)')
    plt.title('CRM acquisition for {} = {} '.format(variable_c, variable_change[var_c]))
    plt.savefig('{}/{}_{}_CRM_acquisition.pdf'.format(dire, variable_c, variable_change[var_c]), bbox_inches='tight')
    
    plt.close()
    return

def plot_TRM_acquired(V, ST, var_c):
    err_t = ST['err_t']
    trm_a = ST['trm_a']
    len_a_trm = ST['len_a_trm']
    temp_a = ST['temp_a']
    name = V['name']
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    i = var_c


    
    plt.plot((temp_a[i][:int(len_a_trm[i])] - 273),trm_a[i][:int(len_a_trm[i])], marker = 'o')

    plt.autoscale()
    plt.ylabel('TRM ')
    plt.xlabel('temperature (degrees C')
    plt.title('TRM acquisition for {} = {} '.format(variable_c, variable_change[var_c]))
    plt.savefig('{}/{}_TRM_acquisition.pdf'.format(dire,variable_change[var_c]), bbox_inches='tight')
   
    plt.close()
    
    return

def plot_sirm(SC, ST, V, var_c):
    sirmC = SC['sirm']
    sirmT = ST['sirm']
    cntfield = SC['cntfield']
    demagstep2 = SC['AF_steps']
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    i = var_c
    

    err_s = ST['err_s']
    
    sirm_err = np.zeros_like(sirmT) 
    sirm_err = err_s*sirmT 

    plt.plot(demagstep2, sirmC[i,:cntfield], 'ro', label = 'CRM') 
    plt.plot(demagstep2, sirmT[i,:cntfield], color = 'b', label = 'TRM') 
    plt.errorbar(demagstep2, sirmT[i,:cntfield], yerr = sirm_err[i,:cntfield])
    
    plt.ylabel('SIRM')
    plt.xlabel('AF demag step (mT')
    plt.legend()
    plt.title('SIRM demagnetisation spectra for {} = {}'.format(variable_c, variable_change[var_c]))
    plt.autoscale()
    plt.savefig('{}/{}_{}_SIRM_demag.pdf'.format(dire,variable_c, variable_change[var_c]), bbox_inches='tight')
    plt.close()
    return

def plot_rem_demag(V, ST, SC, var_c):
    i = var_c

    dire = V['dir']
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    af_step = ST['AF_steps']
    afmag_T = ST['afmag']/ST['sirm'][i,0]
    afmag_C = SC['afmag']/SC['sirm'][i,0]
    
        
    
    plt.plot(af_step, afmag_T[i][:len(af_step)], 'b', label = 'TRM') 
    plt.plot(af_step, afmag_C[i][:len(af_step)], 'g', label='CRM') 
    


    plt.ylabel('TRM/SIRM or CRM/SIRM')
    plt.xlabel('AF demagnetisation step (mT)')
    plt.legend()
    plt.title('Demagnetisation of TRM and CRM spectra \n' + r'(normalised to max SIRM) for {} = {}'.format(variable_c, variable_change[var_c]))
    plt.autoscale()
    plt.savefig('{}/{}_{}_AF_demag_TRM_CRM_norm_SIRM.pdf'.format(dire,variable_c, variable_change[var_c]), bbox_inches='tight')
    plt.close()
    
    return

def TRM_AF_demag(V, ST, var_c):
    i = var_c
    err_t = ST['err_t'] + ST['err_s'] 

    err_s = ST['err_s']
    
    dire = V['dir']
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    af_step = ST['AF_steps']
    afmag_T = ST['afmag']/ST['sirm'][i,0]

    trm_a_err = np.zeros_like(afmag_T) 
    trm_a_err = err_t*afmag_T    
    
    plt.plot(af_step, afmag_T[i][:len(af_step)], 'b') 
    plt.errorbar(af_step, afmag_T[i][:len(af_step)], yerr = trm_a_err[i][:len(af_step)])  
    plt.plot([],[], 'b', label='TRM')
    plt.ylabel('TRM/SIRM')
    plt.xlabel('AF step (mT)')
    plt.legend()
    plt.title('AF demagnetisation of TRM/SIRM \n' + r' for {} = {}'.format(variable_c, variable_change[var_c]))
    plt.autoscale()
    plt.savefig('{}\{}_{}_AF_demag_TRM_norm_SIRM.pdf'.format(dire,variable_c, variable_change[var_c]), bbox_inches='tight')
    plt.close()
    
    return
    
    
def CRM_AF_demag(V, SC, var_c):
    i = var_c

    err_c = SC['err_c'] + SC['err_s']

    dire = V['dir']
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    af_step = SC['AF_steps']

    afmag_C = SC['afmag']/SC['sirm'][i,0]
    crm_a_err = np.zeros_like(afmag_C) 
    crm_a_err = err_c*afmag_C 
 
    plt.plot(af_step, afmag_C[i][:len(af_step)], 'g') 
    
   
    plt.errorbar(af_step, afmag_C[i][:len(af_step)], yerr = crm_a_err[i][:len(af_step)]) 

    plt.plot([],[], 'g', label='CRM')

    plt.ylabel('CRM/SIRM')
    plt.xlabel('AF step (mT)')
    plt.legend()
    plt.title('AF demagnetisation of CRM/SIRM \n' + r' for {} = {}'.format(variable_c, variable_change[var_c]))
    plt.autoscale()
    plt.savefig('{}/{}_{}_AF_demag_CRM_norm_SIRM.pdf'.format(dire,variable_c, variable_change[var_c]), bbox_inches='tight')
    plt.close()
    
    return    

def CRM_TRM_var(SC, ST, V):   
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']

    err_t = ST['err_t'] + ST['err_s'] 
    err_c = SC['err_c'] + SC['err_s']


    norm_TRM = ST['max_trm'][:len(V['variable_change'])]/ST['sirm'][:len(V['variable_change']),0]
    norm_CRM = SC['max_crm'][:len(V['variable_change'])]/SC['sirm'][:len(V['variable_change']),0]
    
    
    trm_a_err = np.zeros_like(norm_CRM) 
    crm_a_err = np.zeros_like(norm_CRM) 
    crm_a_err = err_c*norm_CRM 
    trm_a_err = err_t*norm_CRM   
      

    plt.scatter(variable_change, norm_TRM, label = 'TRM')
    plt.scatter(variable_change, norm_CRM, label = 'CRM')
    
    plt.errorbar(variable_change, norm_TRM, yerr = trm_a_err, fmt = 'none')     
    plt.errorbar(variable_change, norm_CRM, yerr = crm_a_err, fmt = 'none')    
    
    plt.legend()
    plt.title('TRM/SIRM or CRM/SIRM vs. {}'.format(variable_c))
    plt.xlabel('{}'.format(variable_c))
    plt.ylabel('max TRM/SIRM or CRM/SIRM')
    plt.savefig('{}/{}_max_mag.pdf'.format(dire,variable_c), bbox_inches='tight')
    plt.close()
    return


def plot_ratios(SC, ST, V):   

	variable_change = V['variable_change']
	variable_c = V['variable_c']
	dire = V['dir']

	err_ra = ST['err_t'] + SC['err_c']
	ratio = SC['max_crm']/ST['max_trm']

	ratio_err = np.zeros_like(ratio)
	ratio_err = err_ra*ratio 


	plt.scatter(variable_change, ratio, label = 'CRM/TRM')
	plt.errorbar(variable_change, ratio, yerr = ratio_err, fmt = 'none')  
   
	plt.autoscale()
	plt.xlim(0, np.max(variable_change))
	plt.legend()
	plt.title('CRM/TRM ratio as vary {}'.format(variable_c))
	plt.xlabel('{}'.format(variable_c))
	plt.ylabel('CRM/TRM')
	plt.savefig('{}/{}_TRM_CRM_ratio.pdf'.format(dire,variable_c), bbox_inches='tight')
	plt.close()    

	return    
    
def SIRM_var(SC, ST, V):   
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    
    
    err_s = ST['err_s']
    sirm_a_err = np.zeros_like(ST['sirm'][:len(V['variable_change']),0]) # zeros arrya for error
    sirm_a_err = err_s*ST['sirm'][:len(V['variable_change']),0]

    plt.scatter(variable_change, ST['sirm'][:len(V['variable_change']),0])
    plt.errorbar(variable_change, ST['sirm'][:len(V['variable_change']),0], yerr = sirm_a_err, fmt = 'none')  
    
    plt.title('Max SIRM for different values of variable: {}'.format(variable_c))
    plt.xlabel('{}'.format(variable_c))
    plt.ylabel('max SIRM)')
    plt.savefig('{}/{}_max_SIRM.pdf'.format(dire,variable_c), bbox_inches='tight')
    plt.close()
    return

def plot_z(V, ST, SC, I, i):
    var_c = i
    dire = V['variable_c']
    name = V['name']
    var_change = V['variable_change']

    variable_c = V['variable_c']

    plt.contourf(ST['x']*1000,ST['y']*1000,ST['z_n'], cmap = 'BuGn') 

    plt.autoscale()

    plt.xlabel('hc (mT)',fontsize=16)
    plt.ylabel('hi (mT)',fontsize=16)
    plt.title('Normalised synthetic FORC \n' + r'Variable {} = {} '.format(variable_c, var_change[var_c]))
    plt.colorbar()

    plt.savefig('{}/{}_{}_FORC.pdf'.format(dire, name, var_change[var_c]), bbox_inches='tight')
	
    plt.close()


def TRM_thermal_demag(TT, ST, V, var_c):
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']
    templist_trm = TT['Ttest_list'][i,:int(TT['len_a_trm_demag'][i])]
    nrm_p = TT['NRM_r']/ST['sirm'][i,0]
    Nrm_r_trm = nrm_p[i][:int(TT['len_a_trm_demag'][i])]
    err_t = TT['err_t']
    nrm_a_err_T = np.zeros_like(Nrm_r_trm) 
    nrm_a_err_T = err_t*Nrm_r_trm     
      
    plt.plot(templist_trm, Nrm_r_trm, label = 'TRM')

    plt.title('Thermal demagnetisation of TRM, normalised to SIRM \n' + r'{} = {} '.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature')
    plt.ylabel('TRM/SIRM')
    
    plt.errorbar(templist_trm, Nrm_r_trm, yerr = nrm_a_err_T, fmt = 'none')  

    plt.xlim(0,600)
    plt.legend()
    plt.savefig('{}/{}_{}_TRM_thermal_demag_plot.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
 
    return


def CRM_thermal_demag(CT, SC, V, var_c):
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']

    templist_crm = CT['Ttest_list'][i,:int(CT['len_a_trm_demag'][i])]
    nrm_p = CT['NRM_r']/SC['sirm'][i,0]
    Nrm_r_crm = nrm_p[i][:int(CT['len_a_trm_demag'][i])]

    err_c = CT['err_c']
    

    nrm_a_err_C = np.zeros_like(Nrm_r_crm) 
    nrm_a_err_C = err_c*Nrm_r_crm 
    
    
    plt.plot((templist_crm-273), Nrm_r_crm, label = 'CRM')

    plt.title('Thermal demagnetisation of CRM/SIRM \n' + r'{} = {} '.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature (degrees C)')
    plt.ylabel('CRM/SIRM')
    
    plt.errorbar(templist_crm, Nrm_r_crm, yerr = nrm_a_err_C, fmt = 'none')     
  
    plt.xlim(0,600)
    plt.legend()
    plt.savefig('{}/{}_{}_CRM_thermal_demag.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    
    return    

def TCRM_thermal_demag(TC_T, V, var_c):
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']

    templist_tcrm = TC_T['Ttest_list'][i,:int(TC_T['len_a_Ttrm_demag'][i])]
    nrm_p = TC_T['NRM_r']/TC_T['sirm'][i,0]
    Nrm_r_tcrm = nrm_p[i][:int(TC_T['len_a_Ttrm_demag'][i])]

    err_c = TC_T['err_c']
    

    nrm_a_err_C = np.zeros_like(Nrm_r_tcrm) 
    nrm_a_err_C = err_c*Nrm_r_tcrm 
    
    
    plt.plot((templist_tcrm-273), Nrm_r_tcrm, label = 'TCRM/HCRM')

    plt.title('Thermal demagnetisation of TCRM/SIRM or HCRM/SIRM \n' + r'{} = {} '.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature (degrees C)')
    plt.ylabel('TCRM/SIRM or HCRM/SIRM')
    
    plt.errorbar(templist_tcrm, Nrm_r_tcrm, yerr = nrm_a_err_C, fmt = 'none')   
  
    plt.xlim(0,600)
    plt.legend()
    plt.savefig('{}/{}_{}_TCRM_HCRM_thermal_demag.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    
    return    
    
  
def TRM_CRM_thermal_demag(TT, CT, SC, V, var_c):
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']
    templist_trm = TT['Ttest_list'][i,:int(TT['len_a_trm_demag'][i])]
    templist_crm = CT['Ttest_list'][i,:int(CT['len_a_trm_demag'][i])]
    nrm_c = CT['NRM_r']/SC['sirm'][i,0]
    Nrm_r_crm = nrm_c[i][:int(CT['len_a_trm_demag'][i])]

    nrm_t = TT['NRM_r']/SC['sirm'][i,0]
    Nrm_r_trm = nrm_t[i][:int(TT['len_a_trm_demag'][i])]

    
    err_t = TT['err_t']
    err_c = CT['err_c']
    
    
    nrm_a_err_C = np.zeros_like(Nrm_r_crm) 
    nrm_a_err_C = err_c*Nrm_r_crm  

    nrm_a_err_T = np.zeros_like(Nrm_r_trm) 
    nrm_a_err_T = err_t*Nrm_r_trm      
    
    plt.plot(templist_trm-273, Nrm_r_trm, label = 'TRM', color = 'b')
    plt.plot(templist_crm-273, Nrm_r_crm, label = 'CRM', color = 'g')

    plt.title('Thermal demagnetisation of CRM/SIRM and TRM/SIRM \n' + r'{} = {} '.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature (degrees C)')
    plt.ylabel('CRM/SIRM or TRM/SIRM')
    
    plt.errorbar(templist_crm, Nrm_r_crm, yerr = nrm_a_err_C, fmt = 'none', color ='g')
    plt.errorbar(templist_trm, Nrm_r_trm, yerr = nrm_a_err_T, fmt = 'none', color = 'b')       

    plt.xlim(0,600)
    plt.legend()
    plt.savefig('{}/{}_{}_CRM_TRM_thermal_demag.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    

    return   

def TRM_arai_plot(TT, V, var_c):

    err_t = TT['err_t'] 

    
    demag_field = TT['demag_field']
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']
    Nrm_r = TT['NRM_r'][i][:int(TT['len_a_trm_demag'][i])]
    ptrm =  TT['pTRM'][i][:int(TT['len_a_trm_demag'][i])]


    nrm_a_err = np.zeros_like(Nrm_r) 
    nrm_a_err = err_t*Nrm_r 
    
    ptm_a_err = np.zeros_like(ptrm) 
    ptm_a_err = err_t*ptrm 

    m, b = np.polyfit(ptrm, Nrm_r, 1)
    
    B_anc = -m*demag_field
    plt.scatter(TT['pTRM'][i][:int(TT['len_a_trm_demag'][i])], TT['NRM_r'][i][:int(TT['len_a_trm_demag'][i])])
    plt.errorbar(TT['pTRM'][i][:int(TT['len_a_trm_demag'][i])], TT['NRM_r'][i][:int(TT['len_a_trm_demag'][i])], xerr = ptm_a_err, yerr = nrm_a_err) #plot error bars
    plt.title('TRM Arai plot for {} = {} \n'.format(variable_c, variable_change[var_c]) + r'true field = {} T, calculated field = {} T, m = {}'.format(field*mu0, B_anc*mu0, m))
        
    plt.xlim(0, max(ptrm))
    plt.ylim(0, max(Nrm_r))

    plt.xlabel('pTRM')
    plt.ylabel('NRM remaining')


    plt.savefig('{}/{}_{}_TRM_arai.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    return
    

def CRM_arai_plot(CT, V, var_c):   
    err_c = CT['err_c'] 
    err_t = CT['err_t']


    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']
    i = var_c
    Nrm_r_crm = CT['NRM_r'][i][:int(CT['len_a_trm_demag'][i])]
    ptrm_crm =  CT['pTRM'][i][:int(CT['len_a_trm_demag'][i])]
    
    ptm_a_err = np.zeros_like(ptrm_crm)
    ptm_a_err = err_t*ptrm_crm  
    
    nrm_a_err = np.zeros_like(Nrm_r_crm) 
    nrm_a_err = err_c*Nrm_r_crm  
    
    plt.scatter(ptrm_crm, Nrm_r_crm)
    plt.errorbar(ptrm_crm, Nrm_r_crm, xerr = ptm_a_err, yerr = nrm_a_err) 
    plt.title('CRM Arai plot for {} = {} \n'.format(variable_c, variable_change[var_c]) + r'true field = {} T'.format((field*mu0)))
    plt.xlim(0, max(ptrm_crm))
    plt.ylim(0,max(Nrm_r_crm))
    plt.xlabel('pTRM')
    plt.ylabel('NRM remaining')
    plt.savefig('{}/{}_{}_CRM_arai.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    return
    
def NRM_pTRM(CT, TT, V, var_c):
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']
    templist_trm = TT['Ttest_list'][i,:int(TT['len_a_trm_demag'][i])]
    templist_crm = CT['Ttest_list'][i,:int(CT['len_a_trm_demag'][i])]
    Nrm_r_crm = CT['NRM_r'][i][:int(CT['len_a_trm_demag'][i])]
    ptrm_crm =  CT['pTRM'][i][:int(CT['len_a_trm_demag'][i])]
    
    
    Nrm_r_trm = TT['NRM_r'][i][:int(TT['len_a_trm_demag'][i])]
    ptrm_trm =  TT['pTRM'][i][:int(TT['len_a_trm_demag'][i])]
    
    err_t = TT['err_t']
    err_c = CT['err_c']
    
    ptm_a_err_C = np.zeros_like(ptrm_crm) 
    ptm_a_err_C = err_t*ptrm_crm 
    
    nrm_a_err_C = np.zeros_like(Nrm_r_crm) 
    nrm_a_err_C = err_c*Nrm_r_crm 
    
    ptm_a_err_T = np.zeros_like(ptrm_trm) 
    ptm_a_err_T = err_t*ptrm_trm 
    
    nrm_a_err_T = np.zeros_like(Nrm_r_trm) 
    nrm_a_err_T = err_t*Nrm_r_trm      
    
    
    
    
    plt.plot(templist_trm-273, Nrm_r_trm, label = 'NRM')
    plt.plot(templist_trm-273, ptrm_trm, label = 'pTRM')
    plt.title('TRM lost and pTRM gained during Thellier \n' + r'{} = {} '.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature (degrees C)')
    plt.ylabel('NRM remaining or pTRM')
    plt.xlim(0,600)    
    plt.errorbar(templist_trm-273, Nrm_r_trm, yerr = nrm_a_err_T, fmt = 'none')   
    plt.errorbar(templist_trm-273, ptrm_trm, yerr = ptm_a_err_T, fmt = 'none') 

    plt.legend()
    plt.savefig('{}/{}_{}_TRM_ptrm_vs_temp.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    
    plt.plot(templist_crm-273,  Nrm_r_crm, label = 'NRM')
    plt.plot(templist_crm-273, ptrm_crm, label = 'pTRM')
    
    plt.errorbar(templist_crm-273, Nrm_r_crm, yerr = nrm_a_err_C, fmt = 'none')   
    plt.errorbar(templist_crm-273, ptrm_crm, yerr = ptm_a_err_C, fmt = 'none')  
    plt.xlim(0,600)
    plt.title('CRM lost and pTRM gained during Thellier \n' + r'{} = {}'.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature (degrees C)')
    plt.ylabel('NRM remaining or pTRM')
    plt.legend()
    plt.savefig('{}/{}_{}_CRM_ptrm_vs_temp.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    return 

def highT_NRM_pTRM(TC_T, V, var_c):
    i = var_c
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    field = V['field']
    templist_tcrm = TC_T['Ttest_list'][i,:int(TC_T['len_a_Ttrm_demag'][i])]

    
    
    Nrm_r_tcrm = TC_T['NRM_r'][i][:int(TC_T['len_a_Ttrm_demag'][i])]
    ptrm_tcrm =  TC_T['pTRM'][i][:int(TC_T['len_a_Ttrm_demag'][i])]
    
    err_t = TC_T['err_t']

    ptm_a_err_T = np.zeros_like(ptrm_tcrm) 
    ptm_a_err_T = err_t*ptrm_tcrm  
    
    nrm_a_err_T = np.zeros_like(Nrm_r_tcrm)
    nrm_a_err_T = err_t*Nrm_r_tcrm     
    
    
    plt.plot(templist_tcrm-273, Nrm_r_tcrm, label = 'NRM')
    plt.plot(templist_tcrm-273, ptrm_tcrm, label = 'pTRM')
    plt.title('TCRM or HCRM lost and pTRM gained during Thellier \n' + r'{} = {} '.format(variable_c, variable_change[var_c])) 
    plt.xlabel('Temperature (degrees C)')
    plt.ylabel('NRM remaining or pTRM')
    plt.xlim(0,600)    
    plt.errorbar(templist_tcrm-273, Nrm_r_tcrm, yerr = nrm_a_err_T, fmt = 'none')    
    plt.errorbar(templist_tcrm-273, ptrm_tcrm, yerr = ptm_a_err_T, fmt = 'none')   

    plt.legend()
    plt.savefig('{}/{}_{}_TCRM_HCRN_ptrm_vs_temp.pdf'.format(dire,variable_c,variable_change[var_c]), bbox_inches='tight')
    plt.close()
    return   

def TCRM_var(TC_A, V):   
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']

    err_tc = TC_A['err_t'] + TC_A['err_s'] 

    norm_TCRM = TC_A['max_tcrm'][:len(V['variable_change'])]/TC_A['sirm'][:len(V['variable_change']),0]
    

    tcrm_a_err = np.zeros_like(norm_TCRM) 
    tcrm_a_err = err_tc*norm_TCRM    
      

    plt.scatter(variable_change, norm_TCRM, label = 'TCRM/SIRM or HCRM/SIRM')
    
    plt.errorbar(variable_change, norm_TCRM, yerr = tcrm_a_err, fmt = 'none')     

    
    plt.legend()
    plt.title('TCRM/SIRM or HCRM/SIRM vs. {}'.format(variable_c))
    plt.xlabel('{}'.format(variable_c))
    plt.ylabel('max TCRM/SIRM or HCRM/SIRM')
    plt.savefig('{}/{}_max_mag.pdf'.format(dire,variable_c), bbox_inches='tight')
    plt.close()
    return

def SIRM_var_HT(TC_A, V):   
    variable_change = V['variable_change']
    variable_c = V['variable_c']
    dire = V['dir']
    
    
    err_s = TC_A['err_s']
    sirm_a_err = np.zeros_like(TC_A['sirm'][:len(V['variable_change']),0]) 
    sirm_a_err = err_s*TC_A['sirm'][:len(V['variable_change']),0]

    plt.scatter(variable_change, TC_A['sirm'][:len(V['variable_change']),0])
    plt.errorbar(variable_change, TC_A['sirm'][:len(V['variable_change']),0], yerr = sirm_a_err, fmt = 'none')  
    
    plt.title('Max SIRM for different values of variable: {}'.format(variable_c))
    plt.xlabel('{}'.format(variable_c))
    plt.ylabel('max SIRM)')
    plt.savefig('{}/{}_max_SIRM.pdf'.format(dire,variable_c), bbox_inches='tight')
    plt.close()
    return